var Pt=Object.defineProperty;var ze=e=>{throw TypeError(e)};var Lt=(e,t,a)=>t in e?Pt(e,t,{enumerable:!0,configurable:!0,writable:!0,value:a}):e[t]=a;var g=(e,t,a)=>Lt(e,typeof t!="symbol"?t+"":t,a),_e=(e,t,a)=>t.has(e)||ze("Cannot "+a);var l=(e,t,a)=>(_e(e,t,"read from private field"),a?a.call(e):t.get(e)),m=(e,t,a)=>t.has(e)?ze("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(e):t.set(e,a),p=(e,t,a,s)=>(_e(e,t,"write to private field"),s?s.call(e,a):t.set(e,a),a),x=(e,t,a)=>(_e(e,t,"access private method"),a);var Je=(e,t,a,s)=>({set _(r){p(e,t,r,a)},get _(){return l(e,t,s)}});var Ve=(e,t,a)=>(s,r)=>{let n=-1;return i(0);async function i(c){if(c<=n)throw new Error("next() called multiple times");n=c;let d,o=!1,u;if(e[c]?(u=e[c][0][0],s.req.routeIndex=c):u=c===e.length&&r||void 0,u)try{d=await u(s,()=>i(c+1))}catch(h){if(h instanceof Error&&t)s.error=h,d=await t(h,s),o=!0;else throw h}else s.finalized===!1&&a&&(d=await a(s));return d&&(s.finalized===!1||o)&&(s.res=d),s}},Dt=Symbol(),Nt=async(e,t=Object.create(null))=>{const{all:a=!1,dot:s=!1}=t,n=(e instanceof gt?e.raw.headers:e.headers).get("Content-Type");return n!=null&&n.startsWith("multipart/form-data")||n!=null&&n.startsWith("application/x-www-form-urlencoded")?Rt(e,{all:a,dot:s}):{}};async function Rt(e,t){const a=await e.formData();return a?Ot(a,t):{}}function Ot(e,t){const a=Object.create(null);return e.forEach((s,r)=>{t.all||r.endsWith("[]")?Ct(a,r,s):a[r]=s}),t.dot&&Object.entries(a).forEach(([s,r])=>{s.includes(".")&&(It(a,s,r),delete a[s])}),a}var Ct=(e,t,a)=>{e[t]!==void 0?Array.isArray(e[t])?e[t].push(a):e[t]=[e[t],a]:t.endsWith("[]")?e[t]=[a]:e[t]=a},It=(e,t,a)=>{let s=e;const r=t.split(".");r.forEach((n,i)=>{i===r.length-1?s[n]=a:((!s[n]||typeof s[n]!="object"||Array.isArray(s[n])||s[n]instanceof File)&&(s[n]=Object.create(null)),s=s[n])})},ct=e=>{const t=e.split("/");return t[0]===""&&t.shift(),t},Ft=e=>{const{groups:t,path:a}=Ht(e),s=ct(a);return _t(s,t)},Ht=e=>{const t=[];return e=e.replace(/\{[^}]+\}/g,(a,s)=>{const r=`@${s}`;return t.push([r,a]),r}),{groups:t,path:e}},_t=(e,t)=>{for(let a=t.length-1;a>=0;a--){const[s]=t[a];for(let r=e.length-1;r>=0;r--)if(e[r].includes(s)){e[r]=e[r].replace(s,t[a][1]);break}}return e},Le={},Bt=(e,t)=>{if(e==="*")return"*";const a=e.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);if(a){const s=`${e}#${t}`;return Le[s]||(a[2]?Le[s]=t&&t[0]!==":"&&t[0]!=="*"?[s,a[1],new RegExp(`^${a[2]}(?=/${t})`)]:[e,a[1],new RegExp(`^${a[2]}$`)]:Le[s]=[e,a[1],!0]),Le[s]}return null},qe=(e,t)=>{try{return t(e)}catch{return e.replace(/(?:%[0-9A-Fa-f]{2})+/g,a=>{try{return t(a)}catch{return a}})}},Kt=e=>qe(e,decodeURI),dt=e=>{const t=e.url,a=t.indexOf("/",t.indexOf(":")+4);let s=a;for(;s<t.length;s++){const r=t.charCodeAt(s);if(r===37){const n=t.indexOf("?",s),i=t.slice(a,n===-1?void 0:n);return Kt(i.includes("%25")?i.replace(/%25/g,"%2525"):i)}else if(r===63)break}return t.slice(a,s)},Ut=e=>{const t=dt(e);return t.length>1&&t.at(-1)==="/"?t.slice(0,-1):t},re=(e,t,...a)=>(a.length&&(t=re(t,...a)),`${(e==null?void 0:e[0])==="/"?"":"/"}${e}${t==="/"?"":`${(e==null?void 0:e.at(-1))==="/"?"":"/"}${(t==null?void 0:t[0])==="/"?t.slice(1):t}`}`),ut=e=>{if(e.charCodeAt(e.length-1)!==63||!e.includes(":"))return null;const t=e.split("/"),a=[];let s="";return t.forEach(r=>{if(r!==""&&!/\:/.test(r))s+="/"+r;else if(/\:/.test(r))if(/\?/.test(r)){a.length===0&&s===""?a.push("/"):a.push(s);const n=r.replace("?","");s+="/"+n,a.push(s)}else s+="/"+r}),a.filter((r,n,i)=>i.indexOf(r)===n)},Be=e=>/[%+]/.test(e)?(e.indexOf("+")!==-1&&(e=e.replace(/\+/g," ")),e.indexOf("%")!==-1?qe(e,pt):e):e,ht=(e,t,a)=>{let s;if(!a&&t&&!/[%+]/.test(t)){let i=e.indexOf("?",8);if(i===-1)return;for(e.startsWith(t,i+1)||(i=e.indexOf(`&${t}`,i+1));i!==-1;){const c=e.charCodeAt(i+t.length+1);if(c===61){const d=i+t.length+2,o=e.indexOf("&",d);return Be(e.slice(d,o===-1?void 0:o))}else if(c==38||isNaN(c))return"";i=e.indexOf(`&${t}`,i+1)}if(s=/[%+]/.test(e),!s)return}const r={};s??(s=/[%+]/.test(e));let n=e.indexOf("?",8);for(;n!==-1;){const i=e.indexOf("&",n+1);let c=e.indexOf("=",n);c>i&&i!==-1&&(c=-1);let d=e.slice(n+1,c===-1?i===-1?void 0:i:c);if(s&&(d=Be(d)),n=i,d==="")continue;let o;c===-1?o="":(o=e.slice(c+1,i===-1?void 0:i),s&&(o=Be(o))),a?(r[d]&&Array.isArray(r[d])||(r[d]=[]),r[d].push(o)):r[d]??(r[d]=o)}return t?r[t]:r},qt=ht,Gt=(e,t)=>ht(e,t,!0),pt=decodeURIComponent,We=e=>qe(e,pt),le,P,B,ft,mt,Ue,q,st,gt=(st=class{constructor(e,t="/",a=[[]]){m(this,B);g(this,"raw");m(this,le);m(this,P);g(this,"routeIndex",0);g(this,"path");g(this,"bodyCache",{});m(this,q,e=>{const{bodyCache:t,raw:a}=this,s=t[e];if(s)return s;const r=Object.keys(t)[0];return r?t[r].then(n=>(r==="json"&&(n=JSON.stringify(n)),new Response(n)[e]())):t[e]=a[e]()});this.raw=e,this.path=t,p(this,P,a),p(this,le,{})}param(e){return e?x(this,B,ft).call(this,e):x(this,B,mt).call(this)}query(e){return qt(this.url,e)}queries(e){return Gt(this.url,e)}header(e){if(e)return this.raw.headers.get(e)??void 0;const t={};return this.raw.headers.forEach((a,s)=>{t[s]=a}),t}async parseBody(e){var t;return(t=this.bodyCache).parsedBody??(t.parsedBody=await Nt(this,e))}json(){return l(this,q).call(this,"text").then(e=>JSON.parse(e))}text(){return l(this,q).call(this,"text")}arrayBuffer(){return l(this,q).call(this,"arrayBuffer")}blob(){return l(this,q).call(this,"blob")}formData(){return l(this,q).call(this,"formData")}addValidatedData(e,t){l(this,le)[e]=t}valid(e){return l(this,le)[e]}get url(){return this.raw.url}get method(){return this.raw.method}get[Dt](){return l(this,P)}get matchedRoutes(){return l(this,P)[0].map(([[,e]])=>e)}get routePath(){return l(this,P)[0].map(([[,e]])=>e)[this.routeIndex].path}},le=new WeakMap,P=new WeakMap,B=new WeakSet,ft=function(e){const t=l(this,P)[0][this.routeIndex][1][e],a=x(this,B,Ue).call(this,t);return a&&/\%/.test(a)?We(a):a},mt=function(){const e={},t=Object.keys(l(this,P)[0][this.routeIndex][1]);for(const a of t){const s=x(this,B,Ue).call(this,l(this,P)[0][this.routeIndex][1][a]);s!==void 0&&(e[a]=/\%/.test(s)?We(s):s)}return e},Ue=function(e){return l(this,P)[1]?l(this,P)[1][e]:e},q=new WeakMap,st),$t={Stringify:1},bt=async(e,t,a,s,r)=>{typeof e=="object"&&!(e instanceof String)&&(e instanceof Promise||(e=e.toString()),e instanceof Promise&&(e=await e));const n=e.callbacks;return n!=null&&n.length?(r?r[0]+=e:r=[e],Promise.all(n.map(c=>c({phase:t,buffer:r,context:s}))).then(c=>Promise.all(c.filter(Boolean).map(d=>bt(d,t,!1,s,r))).then(()=>r[0]))):Promise.resolve(e)},zt="text/plain; charset=UTF-8",Ke=(e,t)=>({"Content-Type":e,...t}),ke,je,I,oe,F,E,Te,ce,de,X,Ae,Se,G,ne,rt,Jt=(rt=class{constructor(e,t){m(this,G);m(this,ke);m(this,je);g(this,"env",{});m(this,I);g(this,"finalized",!1);g(this,"error");m(this,oe);m(this,F);m(this,E);m(this,Te);m(this,ce);m(this,de);m(this,X);m(this,Ae);m(this,Se);g(this,"render",(...e)=>(l(this,ce)??p(this,ce,t=>this.html(t)),l(this,ce).call(this,...e)));g(this,"setLayout",e=>p(this,Te,e));g(this,"getLayout",()=>l(this,Te));g(this,"setRenderer",e=>{p(this,ce,e)});g(this,"header",(e,t,a)=>{this.finalized&&p(this,E,new Response(l(this,E).body,l(this,E)));const s=l(this,E)?l(this,E).headers:l(this,X)??p(this,X,new Headers);t===void 0?s.delete(e):a!=null&&a.append?s.append(e,t):s.set(e,t)});g(this,"status",e=>{p(this,oe,e)});g(this,"set",(e,t)=>{l(this,I)??p(this,I,new Map),l(this,I).set(e,t)});g(this,"get",e=>l(this,I)?l(this,I).get(e):void 0);g(this,"newResponse",(...e)=>x(this,G,ne).call(this,...e));g(this,"body",(e,t,a)=>x(this,G,ne).call(this,e,t,a));g(this,"text",(e,t,a)=>!l(this,X)&&!l(this,oe)&&!t&&!a&&!this.finalized?new Response(e):x(this,G,ne).call(this,e,t,Ke(zt,a)));g(this,"json",(e,t,a)=>x(this,G,ne).call(this,JSON.stringify(e),t,Ke("application/json",a)));g(this,"html",(e,t,a)=>{const s=r=>x(this,G,ne).call(this,r,t,Ke("text/html; charset=UTF-8",a));return typeof e=="object"?bt(e,$t.Stringify,!1,{}).then(s):s(e)});g(this,"redirect",(e,t)=>{const a=String(e);return this.header("Location",/[^\x00-\xFF]/.test(a)?encodeURI(a):a),this.newResponse(null,t??302)});g(this,"notFound",()=>(l(this,de)??p(this,de,()=>new Response),l(this,de).call(this,this)));p(this,ke,e),t&&(p(this,F,t.executionCtx),this.env=t.env,p(this,de,t.notFoundHandler),p(this,Se,t.path),p(this,Ae,t.matchResult))}get req(){return l(this,je)??p(this,je,new gt(l(this,ke),l(this,Se),l(this,Ae))),l(this,je)}get event(){if(l(this,F)&&"respondWith"in l(this,F))return l(this,F);throw Error("This context has no FetchEvent")}get executionCtx(){if(l(this,F))return l(this,F);throw Error("This context has no ExecutionContext")}get res(){return l(this,E)||p(this,E,new Response(null,{headers:l(this,X)??p(this,X,new Headers)}))}set res(e){if(l(this,E)&&e){e=new Response(e.body,e);for(const[t,a]of l(this,E).headers.entries())if(t!=="content-type")if(t==="set-cookie"){const s=l(this,E).headers.getSetCookie();e.headers.delete("set-cookie");for(const r of s)e.headers.append("set-cookie",r)}else e.headers.set(t,a)}p(this,E,e),this.finalized=!0}get var(){return l(this,I)?Object.fromEntries(l(this,I)):{}}},ke=new WeakMap,je=new WeakMap,I=new WeakMap,oe=new WeakMap,F=new WeakMap,E=new WeakMap,Te=new WeakMap,ce=new WeakMap,de=new WeakMap,X=new WeakMap,Ae=new WeakMap,Se=new WeakMap,G=new WeakSet,ne=function(e,t,a){const s=l(this,E)?new Headers(l(this,E).headers):l(this,X)??new Headers;if(typeof t=="object"&&"headers"in t){const n=t.headers instanceof Headers?t.headers:new Headers(t.headers);for(const[i,c]of n)i.toLowerCase()==="set-cookie"?s.append(i,c):s.set(i,c)}if(a)for(const[n,i]of Object.entries(a))if(typeof i=="string")s.set(n,i);else{s.delete(n);for(const c of i)s.append(n,c)}const r=typeof t=="number"?t:(t==null?void 0:t.status)??l(this,oe);return new Response(e,{status:r,headers:s})},rt),w="ALL",Vt="all",Wt=["get","post","put","delete","options","patch"],xt="Can not add a route since the matcher is already built.",vt=class extends Error{},Yt="__COMPOSED_HANDLER",Xt=e=>e.text("404 Not Found",404),Ye=(e,t)=>{if("getResponse"in e){const a=e.getResponse();return t.newResponse(a.body,a)}return console.error(e),t.text("Internal Server Error",500)},L,k,yt,D,W,Ne,Re,ue,Qt=(ue=class{constructor(t={}){m(this,k);g(this,"get");g(this,"post");g(this,"put");g(this,"delete");g(this,"options");g(this,"patch");g(this,"all");g(this,"on");g(this,"use");g(this,"router");g(this,"getPath");g(this,"_basePath","/");m(this,L,"/");g(this,"routes",[]);m(this,D,Xt);g(this,"errorHandler",Ye);g(this,"onError",t=>(this.errorHandler=t,this));g(this,"notFound",t=>(p(this,D,t),this));g(this,"fetch",(t,...a)=>x(this,k,Re).call(this,t,a[1],a[0],t.method));g(this,"request",(t,a,s,r)=>t instanceof Request?this.fetch(a?new Request(t,a):t,s,r):(t=t.toString(),this.fetch(new Request(/^https?:\/\//.test(t)?t:`http://localhost${re("/",t)}`,a),s,r)));g(this,"fire",()=>{addEventListener("fetch",t=>{t.respondWith(x(this,k,Re).call(this,t.request,t,void 0,t.request.method))})});[...Wt,Vt].forEach(n=>{this[n]=(i,...c)=>(typeof i=="string"?p(this,L,i):x(this,k,W).call(this,n,l(this,L),i),c.forEach(d=>{x(this,k,W).call(this,n,l(this,L),d)}),this)}),this.on=(n,i,...c)=>{for(const d of[i].flat()){p(this,L,d);for(const o of[n].flat())c.map(u=>{x(this,k,W).call(this,o.toUpperCase(),l(this,L),u)})}return this},this.use=(n,...i)=>(typeof n=="string"?p(this,L,n):(p(this,L,"*"),i.unshift(n)),i.forEach(c=>{x(this,k,W).call(this,w,l(this,L),c)}),this);const{strict:s,...r}=t;Object.assign(this,r),this.getPath=s??!0?t.getPath??dt:Ut}route(t,a){const s=this.basePath(t);return a.routes.map(r=>{var i;let n;a.errorHandler===Ye?n=r.handler:(n=async(c,d)=>(await Ve([],a.errorHandler)(c,()=>r.handler(c,d))).res,n[Yt]=r.handler),x(i=s,k,W).call(i,r.method,r.path,n)}),this}basePath(t){const a=x(this,k,yt).call(this);return a._basePath=re(this._basePath,t),a}mount(t,a,s){let r,n;s&&(typeof s=="function"?n=s:(n=s.optionHandler,s.replaceRequest===!1?r=d=>d:r=s.replaceRequest));const i=n?d=>{const o=n(d);return Array.isArray(o)?o:[o]}:d=>{let o;try{o=d.executionCtx}catch{}return[d.env,o]};r||(r=(()=>{const d=re(this._basePath,t),o=d==="/"?0:d.length;return u=>{const h=new URL(u.url);return h.pathname=h.pathname.slice(o)||"/",new Request(h,u)}})());const c=async(d,o)=>{const u=await a(r(d.req.raw),...i(d));if(u)return u;await o()};return x(this,k,W).call(this,w,re(t,"*"),c),this}},L=new WeakMap,k=new WeakSet,yt=function(){const t=new ue({router:this.router,getPath:this.getPath});return t.errorHandler=this.errorHandler,p(t,D,l(this,D)),t.routes=this.routes,t},D=new WeakMap,W=function(t,a,s){t=t.toUpperCase(),a=re(this._basePath,a);const r={basePath:this._basePath,path:a,method:t,handler:s};this.router.add(t,a,[s,r]),this.routes.push(r)},Ne=function(t,a){if(t instanceof Error)return this.errorHandler(t,a);throw t},Re=function(t,a,s,r){if(r==="HEAD")return(async()=>new Response(null,await x(this,k,Re).call(this,t,a,s,"GET")))();const n=this.getPath(t,{env:s}),i=this.router.match(r,n),c=new Jt(t,{path:n,matchResult:i,env:s,executionCtx:a,notFoundHandler:l(this,D)});if(i[0].length===1){let o;try{o=i[0][0][0][0](c,async()=>{c.res=await l(this,D).call(this,c)})}catch(u){return x(this,k,Ne).call(this,u,c)}return o instanceof Promise?o.then(u=>u||(c.finalized?c.res:l(this,D).call(this,c))).catch(u=>x(this,k,Ne).call(this,u,c)):o??l(this,D).call(this,c)}const d=Ve(i[0],this.errorHandler,l(this,D));return(async()=>{try{const o=await d(c);if(!o.finalized)throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");return o.res}catch(o){return x(this,k,Ne).call(this,o,c)}})()},ue),wt=[];function Zt(e,t){const a=this.buildAllMatchers(),s=((r,n)=>{const i=a[r]||a[w],c=i[2][n];if(c)return c;const d=n.match(i[0]);if(!d)return[[],wt];const o=d.indexOf("",1);return[i[1][o],d]});return this.match=s,s(e,t)}var Ce="[^/]+",xe=".*",ve="(?:|/.*)",ie=Symbol(),ea=new Set(".\\+*[^]$()");function ta(e,t){return e.length===1?t.length===1?e<t?-1:1:-1:t.length===1||e===xe||e===ve?1:t===xe||t===ve?-1:e===Ce?1:t===Ce?-1:e.length===t.length?e<t?-1:1:t.length-e.length}var Q,Z,N,ae,aa=(ae=class{constructor(){m(this,Q);m(this,Z);m(this,N,Object.create(null))}insert(t,a,s,r,n){if(t.length===0){if(l(this,Q)!==void 0)throw ie;if(n)return;p(this,Q,a);return}const[i,...c]=t,d=i==="*"?c.length===0?["","",xe]:["","",Ce]:i==="/*"?["","",ve]:i.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);let o;if(d){const u=d[1];let h=d[2]||Ce;if(u&&d[2]&&(h===".*"||(h=h.replace(/^\((?!\?:)(?=[^)]+\)$)/,"(?:"),/\((?!\?:)/.test(h))))throw ie;if(o=l(this,N)[h],!o){if(Object.keys(l(this,N)).some(f=>f!==xe&&f!==ve))throw ie;if(n)return;o=l(this,N)[h]=new ae,u!==""&&p(o,Z,r.varIndex++)}!n&&u!==""&&s.push([u,l(o,Z)])}else if(o=l(this,N)[i],!o){if(Object.keys(l(this,N)).some(u=>u.length>1&&u!==xe&&u!==ve))throw ie;if(n)return;o=l(this,N)[i]=new ae}o.insert(c,a,s,r,n)}buildRegExpStr(){const a=Object.keys(l(this,N)).sort(ta).map(s=>{const r=l(this,N)[s];return(typeof l(r,Z)=="number"?`(${s})@${l(r,Z)}`:ea.has(s)?`\\${s}`:s)+r.buildRegExpStr()});return typeof l(this,Q)=="number"&&a.unshift(`#${l(this,Q)}`),a.length===0?"":a.length===1?a[0]:"(?:"+a.join("|")+")"}},Q=new WeakMap,Z=new WeakMap,N=new WeakMap,ae),Ie,Ee,nt,sa=(nt=class{constructor(){m(this,Ie,{varIndex:0});m(this,Ee,new aa)}insert(e,t,a){const s=[],r=[];for(let i=0;;){let c=!1;if(e=e.replace(/\{[^}]+\}/g,d=>{const o=`@\\${i}`;return r[i]=[o,d],i++,c=!0,o}),!c)break}const n=e.match(/(?::[^\/]+)|(?:\/\*$)|./g)||[];for(let i=r.length-1;i>=0;i--){const[c]=r[i];for(let d=n.length-1;d>=0;d--)if(n[d].indexOf(c)!==-1){n[d]=n[d].replace(c,r[i][1]);break}}return l(this,Ee).insert(n,t,s,l(this,Ie),a),s}buildRegExp(){let e=l(this,Ee).buildRegExpStr();if(e==="")return[/^$/,[],[]];let t=0;const a=[],s=[];return e=e.replace(/#(\d+)|@(\d+)|\.\*\$/g,(r,n,i)=>n!==void 0?(a[++t]=Number(n),"$()"):(i!==void 0&&(s[Number(i)]=++t),"")),[new RegExp(`^${e}`),a,s]}},Ie=new WeakMap,Ee=new WeakMap,nt),ra=[/^$/,[],Object.create(null)],Oe=Object.create(null);function kt(e){return Oe[e]??(Oe[e]=new RegExp(e==="*"?"":`^${e.replace(/\/\*$|([.\\+*[^\]$()])/g,(t,a)=>a?`\\${a}`:"(?:|/.*)")}$`))}function na(){Oe=Object.create(null)}function ia(e){var o;const t=new sa,a=[];if(e.length===0)return ra;const s=e.map(u=>[!/\*|\/:/.test(u[0]),...u]).sort(([u,h],[f,v])=>u?1:f?-1:h.length-v.length),r=Object.create(null);for(let u=0,h=-1,f=s.length;u<f;u++){const[v,j,R]=s[u];v?r[j]=[R.map(([T])=>[T,Object.create(null)]),wt]:h++;let y;try{y=t.insert(j,h,v)}catch(T){throw T===ie?new vt(j):T}v||(a[h]=R.map(([T,K])=>{const Me=Object.create(null);for(K-=1;K>=0;K--){const[Pe,O]=y[K];Me[Pe]=O}return[T,Me]}))}const[n,i,c]=t.buildRegExp();for(let u=0,h=a.length;u<h;u++)for(let f=0,v=a[u].length;f<v;f++){const j=(o=a[u][f])==null?void 0:o[1];if(!j)continue;const R=Object.keys(j);for(let y=0,T=R.length;y<T;y++)j[R[y]]=c[j[R[y]]]}const d=[];for(const u in i)d[u]=a[i[u]];return[n,d,r]}function se(e,t){if(e){for(const a of Object.keys(e).sort((s,r)=>r.length-s.length))if(kt(a).test(t))return[...e[a]]}}var $,z,Fe,jt,it,la=(it=class{constructor(){m(this,Fe);g(this,"name","RegExpRouter");m(this,$);m(this,z);g(this,"match",Zt);p(this,$,{[w]:Object.create(null)}),p(this,z,{[w]:Object.create(null)})}add(e,t,a){var c;const s=l(this,$),r=l(this,z);if(!s||!r)throw new Error(xt);s[e]||[s,r].forEach(d=>{d[e]=Object.create(null),Object.keys(d[w]).forEach(o=>{d[e][o]=[...d[w][o]]})}),t==="/*"&&(t="*");const n=(t.match(/\/:/g)||[]).length;if(/\*$/.test(t)){const d=kt(t);e===w?Object.keys(s).forEach(o=>{var u;(u=s[o])[t]||(u[t]=se(s[o],t)||se(s[w],t)||[])}):(c=s[e])[t]||(c[t]=se(s[e],t)||se(s[w],t)||[]),Object.keys(s).forEach(o=>{(e===w||e===o)&&Object.keys(s[o]).forEach(u=>{d.test(u)&&s[o][u].push([a,n])})}),Object.keys(r).forEach(o=>{(e===w||e===o)&&Object.keys(r[o]).forEach(u=>d.test(u)&&r[o][u].push([a,n]))});return}const i=ut(t)||[t];for(let d=0,o=i.length;d<o;d++){const u=i[d];Object.keys(r).forEach(h=>{var f;(e===w||e===h)&&((f=r[h])[u]||(f[u]=[...se(s[h],u)||se(s[w],u)||[]]),r[h][u].push([a,n-o+d+1]))})}}buildAllMatchers(){const e=Object.create(null);return Object.keys(l(this,z)).concat(Object.keys(l(this,$))).forEach(t=>{e[t]||(e[t]=x(this,Fe,jt).call(this,t))}),p(this,$,p(this,z,void 0)),na(),e}},$=new WeakMap,z=new WeakMap,Fe=new WeakSet,jt=function(e){const t=[];let a=e===w;return[l(this,$),l(this,z)].forEach(s=>{const r=s[e]?Object.keys(s[e]).map(n=>[n,s[e][n]]):[];r.length!==0?(a||(a=!0),t.push(...r)):e!==w&&t.push(...Object.keys(s[w]).map(n=>[n,s[w][n]]))}),a?ia(t):null},it),J,H,lt,oa=(lt=class{constructor(e){g(this,"name","SmartRouter");m(this,J,[]);m(this,H,[]);p(this,J,e.routers)}add(e,t,a){if(!l(this,H))throw new Error(xt);l(this,H).push([e,t,a])}match(e,t){if(!l(this,H))throw new Error("Fatal error");const a=l(this,J),s=l(this,H),r=a.length;let n=0,i;for(;n<r;n++){const c=a[n];try{for(let d=0,o=s.length;d<o;d++)c.add(...s[d]);i=c.match(e,t)}catch(d){if(d instanceof vt)continue;throw d}this.match=c.match.bind(c),p(this,J,[c]),p(this,H,void 0);break}if(n===r)throw new Error("Fatal error");return this.name=`SmartRouter + ${this.activeRouter.name}`,i}get activeRouter(){if(l(this,H)||l(this,J).length!==1)throw new Error("No active router has been determined yet.");return l(this,J)[0]}},J=new WeakMap,H=new WeakMap,lt),me=Object.create(null),V,S,ee,he,A,_,Y,pe,ca=(pe=class{constructor(t,a,s){m(this,_);m(this,V);m(this,S);m(this,ee);m(this,he,0);m(this,A,me);if(p(this,S,s||Object.create(null)),p(this,V,[]),t&&a){const r=Object.create(null);r[t]={handler:a,possibleKeys:[],score:0},p(this,V,[r])}p(this,ee,[])}insert(t,a,s){p(this,he,++Je(this,he)._);let r=this;const n=Ft(a),i=[];for(let c=0,d=n.length;c<d;c++){const o=n[c],u=n[c+1],h=Bt(o,u),f=Array.isArray(h)?h[0]:o;if(f in l(r,S)){r=l(r,S)[f],h&&i.push(h[1]);continue}l(r,S)[f]=new pe,h&&(l(r,ee).push(h),i.push(h[1])),r=l(r,S)[f]}return l(r,V).push({[t]:{handler:s,possibleKeys:i.filter((c,d,o)=>o.indexOf(c)===d),score:l(this,he)}}),r}search(t,a){var d;const s=[];p(this,A,me);let n=[this];const i=ct(a),c=[];for(let o=0,u=i.length;o<u;o++){const h=i[o],f=o===u-1,v=[];for(let j=0,R=n.length;j<R;j++){const y=n[j],T=l(y,S)[h];T&&(p(T,A,l(y,A)),f?(l(T,S)["*"]&&s.push(...x(this,_,Y).call(this,l(T,S)["*"],t,l(y,A))),s.push(...x(this,_,Y).call(this,T,t,l(y,A)))):v.push(T));for(let K=0,Me=l(y,ee).length;K<Me;K++){const Pe=l(y,ee)[K],O=l(y,A)===me?{}:{...l(y,A)};if(Pe==="*"){const U=l(y,S)["*"];U&&(s.push(...x(this,_,Y).call(this,U,t,l(y,A))),p(U,A,O),v.push(U));continue}const[Et,$e,fe]=Pe;if(!h&&!(fe instanceof RegExp))continue;const C=l(y,S)[Et],Mt=i.slice(o).join("/");if(fe instanceof RegExp){const U=fe.exec(Mt);if(U){if(O[$e]=U[0],s.push(...x(this,_,Y).call(this,C,t,l(y,A),O)),Object.keys(l(C,S)).length){p(C,A,O);const He=((d=U[0].match(/\//))==null?void 0:d.length)??0;(c[He]||(c[He]=[])).push(C)}continue}}(fe===!0||fe.test(h))&&(O[$e]=h,f?(s.push(...x(this,_,Y).call(this,C,t,O,l(y,A))),l(C,S)["*"]&&s.push(...x(this,_,Y).call(this,l(C,S)["*"],t,O,l(y,A)))):(p(C,A,O),v.push(C)))}}n=v.concat(c.shift()??[])}return s.length>1&&s.sort((o,u)=>o.score-u.score),[s.map(({handler:o,params:u})=>[o,u])]}},V=new WeakMap,S=new WeakMap,ee=new WeakMap,he=new WeakMap,A=new WeakMap,_=new WeakSet,Y=function(t,a,s,r){const n=[];for(let i=0,c=l(t,V).length;i<c;i++){const d=l(t,V)[i],o=d[a]||d[w],u={};if(o!==void 0&&(o.params=Object.create(null),n.push(o),s!==me||r&&r!==me))for(let h=0,f=o.possibleKeys.length;h<f;h++){const v=o.possibleKeys[h],j=u[o.score];o.params[v]=r!=null&&r[v]&&!j?r[v]:s[v]??(r==null?void 0:r[v]),u[o.score]=!0}}return n},pe),te,ot,da=(ot=class{constructor(){g(this,"name","TrieRouter");m(this,te);p(this,te,new ca)}add(e,t,a){const s=ut(t);if(s){for(let r=0,n=s.length;r<n;r++)l(this,te).insert(e,s[r],a);return}l(this,te).insert(e,t,a)}match(e,t){return l(this,te).search(e,t)}},te=new WeakMap,ot),Tt=class extends Qt{constructor(e={}){super(e),this.router=e.router??new oa({routers:[new la,new da]})}},ua=e=>{const a={...{origin:"*",allowMethods:["GET","HEAD","PUT","POST","DELETE","PATCH"],allowHeaders:[],exposeHeaders:[]},...e},s=(n=>typeof n=="string"?n==="*"?()=>n:i=>n===i?i:null:typeof n=="function"?n:i=>n.includes(i)?i:null)(a.origin),r=(n=>typeof n=="function"?n:Array.isArray(n)?()=>n:()=>[])(a.allowMethods);return async function(i,c){var u;function d(h,f){i.res.headers.set(h,f)}const o=await s(i.req.header("origin")||"",i);if(o&&d("Access-Control-Allow-Origin",o),a.credentials&&d("Access-Control-Allow-Credentials","true"),(u=a.exposeHeaders)!=null&&u.length&&d("Access-Control-Expose-Headers",a.exposeHeaders.join(",")),i.req.method==="OPTIONS"){a.origin!=="*"&&d("Vary","Origin"),a.maxAge!=null&&d("Access-Control-Max-Age",a.maxAge.toString());const h=await r(i.req.header("origin")||"",i);h.length&&d("Access-Control-Allow-Methods",h.join(","));let f=a.allowHeaders;if(!(f!=null&&f.length)){const v=i.req.header("Access-Control-Request-Headers");v&&(f=v.split(/\s*,\s*/))}return f!=null&&f.length&&(d("Access-Control-Allow-Headers",f.join(",")),i.res.headers.append("Vary","Access-Control-Request-Headers")),i.res.headers.delete("Content-Length"),i.res.headers.delete("Content-Type"),new Response(null,{headers:i.res.headers,status:204,statusText:"No Content"})}await c(),a.origin!=="*"&&i.header("Vary","Origin",{append:!0})}},ha=/^\s*(?:text\/(?!event-stream(?:[;\s]|$))[^;\s]+|application\/(?:javascript|json|xml|xml-dtd|ecmascript|dart|postscript|rtf|tar|toml|vnd\.dart|vnd\.ms-fontobject|vnd\.ms-opentype|wasm|x-httpd-php|x-javascript|x-ns-proxy-autoconfig|x-sh|x-tar|x-virtualbox-hdd|x-virtualbox-ova|x-virtualbox-ovf|x-virtualbox-vbox|x-virtualbox-vdi|x-virtualbox-vhd|x-virtualbox-vmdk|x-www-form-urlencoded)|font\/(?:otf|ttf)|image\/(?:bmp|vnd\.adobe\.photoshop|vnd\.microsoft\.icon|vnd\.ms-dds|x-icon|x-ms-bmp)|message\/rfc822|model\/gltf-binary|x-shader\/x-fragment|x-shader\/x-vertex|[^;\s]+?\+(?:json|text|xml|yaml))(?:[;\s]|$)/i,Xe=(e,t=ga)=>{const a=/\.([a-zA-Z0-9]+?)$/,s=e.match(a);if(!s)return;let r=t[s[1]];return r&&r.startsWith("text")&&(r+="; charset=utf-8"),r},pa={aac:"audio/aac",avi:"video/x-msvideo",avif:"image/avif",av1:"video/av1",bin:"application/octet-stream",bmp:"image/bmp",css:"text/css",csv:"text/csv",eot:"application/vnd.ms-fontobject",epub:"application/epub+zip",gif:"image/gif",gz:"application/gzip",htm:"text/html",html:"text/html",ico:"image/x-icon",ics:"text/calendar",jpeg:"image/jpeg",jpg:"image/jpeg",js:"text/javascript",json:"application/json",jsonld:"application/ld+json",map:"application/json",mid:"audio/x-midi",midi:"audio/x-midi",mjs:"text/javascript",mp3:"audio/mpeg",mp4:"video/mp4",mpeg:"video/mpeg",oga:"audio/ogg",ogv:"video/ogg",ogx:"application/ogg",opus:"audio/opus",otf:"font/otf",pdf:"application/pdf",png:"image/png",rtf:"application/rtf",svg:"image/svg+xml",tif:"image/tiff",tiff:"image/tiff",ts:"video/mp2t",ttf:"font/ttf",txt:"text/plain",wasm:"application/wasm",webm:"video/webm",weba:"audio/webm",webmanifest:"application/manifest+json",webp:"image/webp",woff:"font/woff",woff2:"font/woff2",xhtml:"application/xhtml+xml",xml:"application/xml",zip:"application/zip","3gp":"video/3gpp","3g2":"video/3gpp2",gltf:"model/gltf+json",glb:"model/gltf-binary"},ga=pa,fa=(...e)=>{let t=e.filter(r=>r!=="").join("/");t=t.replace(new RegExp("(?<=\\/)\\/+","g"),"");const a=t.split("/"),s=[];for(const r of a)r===".."&&s.length>0&&s.at(-1)!==".."?s.pop():r!=="."&&s.push(r);return s.join("/")||"."},At={br:".br",zstd:".zst",gzip:".gz"},ma=Object.keys(At),ba="index.html",xa=e=>{const t=e.root??"./",a=e.path,s=e.join??fa;return async(r,n)=>{var u,h,f,v;if(r.finalized)return n();let i;if(e.path)i=e.path;else try{if(i=decodeURIComponent(r.req.path),/(?:^|[\/\\])\.\.(?:$|[\/\\])/.test(i))throw new Error}catch{return await((u=e.onNotFound)==null?void 0:u.call(e,r.req.path,r)),n()}let c=s(t,!a&&e.rewriteRequestPath?e.rewriteRequestPath(i):i);e.isDir&&await e.isDir(c)&&(c=s(c,ba));const d=e.getContent;let o=await d(c,r);if(o instanceof Response)return r.newResponse(o.body,o);if(o){const j=e.mimes&&Xe(c,e.mimes)||Xe(c);if(r.header("Content-Type",j||"application/octet-stream"),e.precompressed&&(!j||ha.test(j))){const R=new Set((h=r.req.header("Accept-Encoding"))==null?void 0:h.split(",").map(y=>y.trim()));for(const y of ma){if(!R.has(y))continue;const T=await d(c+At[y],r);if(T){o=T,r.header("Content-Encoding",y),r.header("Vary","Accept-Encoding",{append:!0});break}}}return await((f=e.onFound)==null?void 0:f.call(e,c,r)),r.body(o)}await((v=e.onNotFound)==null?void 0:v.call(e,c,r)),await n()}},va=async(e,t)=>{let a;t&&t.manifest?typeof t.manifest=="string"?a=JSON.parse(t.manifest):a=t.manifest:typeof __STATIC_CONTENT_MANIFEST=="string"?a=JSON.parse(__STATIC_CONTENT_MANIFEST):a=__STATIC_CONTENT_MANIFEST;let s;t&&t.namespace?s=t.namespace:s=__STATIC_CONTENT;const r=a[e]||e;if(!r)return null;const n=await s.get(r,{type:"stream"});return n||null},ya=e=>async function(a,s){return xa({...e,getContent:async n=>va(n,{manifest:e.manifest,namespace:e.namespace?e.namespace:a.env?a.env.__STATIC_CONTENT:void 0})})(a,s)},wa=e=>ya(e);async function ka(e,t){try{const s=(await e.prepare(`
      INSERT INTO transactions (nomor_ba, tanggal, jenis_transaksi, lokasi_asal, lokasi_tujuan, pemeriksa, penerima, ttd_pemeriksa, ttd_penerima)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(t.nomorBA,t.tanggal,t.jenisTransaksi,t.lokasiAsal,t.lokasiTujuan,t.pemeriksa,t.penerima,t.ttdPemeriksa,t.ttdPenerima).run()).meta.last_row_id;for(const r of t.materials)await e.prepare(`
        INSERT INTO materials (transaction_id, part_number, jenis_barang, material, mesin, sn_mesin, jumlah)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).bind(s,r.partNumber,r.jenisBarang,r.material,r.mesin,r.snMesin,r.jumlah).run();return{success:!0,id:s,nomorBA:t.nomorBA}}catch(a){throw console.error("Failed to save transaction:",a),new Error(`Database error: ${a.message}`)}}async function ja(e){try{const{results:t}=await e.prepare(`
      SELECT 
        t.*,
        json_group_array(
          json_object(
            'partNumber', m.part_number,
            'jenisBarang', m.jenis_barang,
            'material', m.material,
            'mesin', m.mesin,
            'snMesin', m.sn_mesin,
            'jumlah', m.jumlah
          )
        ) as materials
      FROM transactions t
      LEFT JOIN materials m ON t.id = m.transaction_id
      GROUP BY t.id
      ORDER BY t.created_at DESC
    `).all();return t.map(a=>({...a,materials:JSON.parse(a.materials)}))}catch(t){return console.error("Failed to get transactions:",t),[]}}async function Ta(e){try{const{results:t}=await e.prepare(`
      SELECT nomor_ba FROM transactions ORDER BY created_at DESC LIMIT 1
    `).all();if(t.length===0)return"BA-2025-0001";const a=t[0];return`BA-2025-${(parseInt(a.nomor_ba.split("-")[2])+1).toString().padStart(4,"0")}`}catch{return"BA-2025-0001"}}const b=new Tt;b.use("/api/*",ua());b.use("/static/*",wa({root:"./public"}));const Aa="https://script.googleusercontent.com/macros/echo?user_content_key=AehSKLibGBLpxhVKoCyNyEKKy3qLChkzbGk3u0B2OCnrRjQaVhgK7zrqCow5s2sWgqaCh97_c6L4jYn8GL1rz-GAlp_GuD3cWN8epmzIRv225YwSNEC6y3wp4ENvOpNITmxK2ic37e8c-UQSH2cbaBLT9mixv92O8sCA-ptW_LnjtZlzNrBzEjWXEKdNgCbOa_ZYVRIAnEzBLqeFCW7XQocgooPzv4xiOKaTXfR81vrwdC_xm4-pJVoMdgmyuldvxNMvM-vokUUcMdTkA-SG6wMRDg2UgAHC34GkfrC6ebYs&lib=MRb65GHGTxo8fAtO2JZr8dy1qv6vbq6ko";let ge=[],M=[],Qe=!1;function Sa(){if(Qe||M.length>0){console.log("⚠️ Sample data already initialized, skipping...");return}console.log("🔧 Initializing sample gangguan data..."),M.push({id:"sample_"+Date.now(),nomorLH05:"SAMPLE001/ND KAL 2/LH05/2025",hariTanggal:new Date().toISOString().slice(0,16),unitULD:"TELAGA",kelompokSPD:"MEKANIK",komponenRusak:"Cylinder Liner",gejala:"Kebocoran pada cylinder liner unit TELAGA",uraianKejadian:"Ditemukan kebocoran oli pada cylinder liner bagian atas",analisaPenyebab:"Seal cylinder liner sudah aus dan perlu diganti",kesimpulan:"Perlu penggantian cylinder liner segera",bebanPuncak:300,dayaMampu:250,pemadaman:"NORMAL",tindakanPenanggulangan:"Isolasi unit sementara dan monitoring ketat",rencanaPerbaikan:"Ganti cylinder liner dalam 24 jam",materials:[{partNumber:"0490 1316",jenisBarang:"SPARE PART UTAMA",material:"CYLINDER LINER",mesin:"TCD 2013",jumlah:1,status:"Pengadaan"}],namaPelapor:"System Admin (Sample Data)",ttdPelapor:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",createdAt:new Date().toISOString()}),Qe=!0,console.log("✅ Sample gangguan data initialized:",M.length,"items")}Sa();let Ze=M.length+1,we=new Map,be=new Map;const et={username:"AMC@12345",password:"12345@AMC"};let ye=new Map,De=[],tt=0;const Ea=300*1e3;async function Ge(){const e=Date.now();if(De.length>0&&e-tt<Ea)return De;try{const t=await fetch(Aa,{headers:{"User-Agent":"Mozilla/5.0"},redirect:"follow"});if(!t.ok)throw new Error(`HTTP error! status: ${t.status}`);const a=await t.json();return De=a,tt=e,a}catch(t){return console.error("Error fetching Google Sheets data:",t),De}}function Ma(){const e=String(Ze).padStart(3,"0"),t=new Date().getFullYear();return Ze++,`${e}/ND KAL 2/LH05/${t}`}function Pa(){const e={};return ge.forEach(t=>{t.materials.forEach(a=>{const s=a.partNumber;e[s]||(e[s]={partNumber:a.partNumber,jenisBarang:a.jenisBarang,material:a.material,mesin:a.mesin,stokMasuk:0,stokKeluar:0,stokAkhir:0,unit:t.lokasiTujuan}),t.jenisTransaksi.includes("Masuk")?e[s].stokMasuk+=a.jumlah:e[s].stokKeluar+=a.jumlah,e[s].stokAkhir=e[s].stokMasuk-e[s].stokKeluar})}),Object.values(e)}function La(){const e={},t=new Date;return t.setHours(0,0,0,0),be.clear(),ge.filter(a=>a.jenisTransaksi.includes("Keluar")).sort((a,s)=>new Date(a.tanggal).getTime()-new Date(s.tanggal).getTime()).forEach(a=>{a.materials.forEach(s=>{if(!s.snMesin)return;const r=`${s.snMesin}_${s.partNumber}`,n=r;be.has(n)||be.set(n,[]);const i=be.get(n);i.push({tanggal:a.tanggal,nomorBA:a.nomorBA,lokasi:a.lokasiTujuan,jumlah:s.jumlah,pemeriksa:a.pemeriksa,penerima:a.penerima,penggantianKe:i.length+1});const c=new Date(a.tanggal);c.setHours(0,0,0,0);const d=t.getTime()-c.getTime(),o=Math.floor(d/(1e3*60*60*24)),u=we.get(s.partNumber),h=(u==null?void 0:u.targetUmurHari)||365;let f="Terpasang",v="green";o>=h?(f="Perlu Diganti",v="red"):o>=h-20&&(f="Mendekati Batas",v="yellow"),e[r]={snMesin:s.snMesin,partNumber:s.partNumber,jenisBarang:s.jenisBarang,material:s.material,mesin:s.mesin,lokasi:a.lokasiTujuan,tanggalPasang:a.tanggal,umurHari:o,targetUmurHari:h,sisaHari:h-o,status:f,statusClass:v,totalPenggantian:i.length}})}),Object.values(e)}b.get("/api/data",async e=>{try{const t=await Ge();return e.json(t)}catch{return e.json({error:"Failed to fetch data"},500)}});b.get("/api/search-part",async e=>{var a;const t=((a=e.req.query("q"))==null?void 0:a.toLowerCase())||"";if(!t)return e.json({results:[]});try{const r=(await Ge()).filter(n=>String(n.PART_NUMBER||"").toLowerCase().includes(t));return e.json({results:r.slice(0,10)})}catch{return e.json({error:"Search failed"},500)}});b.get("/api/dropdown-values",async e=>{try{const t=await Ge(),a=[...new Set(t.map(n=>n.UNIT).filter(Boolean))].sort(),s=[...new Set(t.map(n=>n.Pemeriksa).filter(Boolean))].sort(),r=[...new Set(t.map(n=>n.Penerima).filter(Boolean))].sort();return e.json({units:a,pemeriksa:s,penerima:r})}catch{return e.json({error:"Failed to get dropdown values"},500)}});b.post("/api/save-transaction",async e=>{try{const{env:t}=e,a=await e.req.json(),s=await Ta(t.DB),r=await ka(t.DB,{nomorBA:s,...a}),n={id:Date.now().toString(),nomorBA:s,...a,createdAt:new Date().toISOString()};return ge.push(n),e.json({success:!0,message:"Transaction saved successfully (D1 Database)",nomorBA:s,data:n})}catch(t){return console.error("Failed to save transaction:",t),e.json({error:t.message||"Failed to save transaction"},500)}});b.get("/api/transactions",async e=>{try{const{env:t}=e,s=[...await ja(t.DB),...ge];return e.json({transactions:s})}catch(t){return console.error("Failed to get transactions:",t),e.json({transactions:ge})}});b.get("/api/dashboard/stock",e=>{const t=e.req.query("jenis")||"",a=e.req.query("mesin")||"";let s=Pa();return t&&(s=s.filter(r=>r.jenisBarang===t)),a&&(s=s.filter(r=>r.mesin===a)),s=s.map(r=>({...r,status:r.stokAkhir===0?"Habis":r.stokAkhir<=10?"Hampir Habis":"Tersedia"})),e.json({stock:s})});b.get("/api/dashboard/umur-material",e=>{const t=e.req.query("lokasi")||"",a=e.req.query("material")||"";let s=La();return t&&(s=s.filter(r=>r.lokasi===t)),a&&(s=s.filter(r=>r.material.includes(a))),e.json({ageData:s})});b.get("/api/ba/:nomor",e=>{const t=e.req.param("nomor"),a=ge.find(s=>s.nomorBA===t);return a?e.json({ba:a}):e.json({error:"BA not found"},404)});b.get("/api/material-history/:snMesin/:partNumber",e=>{const t=e.req.param("snMesin"),a=e.req.param("partNumber"),s=`${t}_${a}`,r=be.get(s)||[];return e.json({snMesin:t,partNumber:a,totalPenggantian:r.length,history:r})});b.get("/api/target-umur",e=>{const t=Array.from(we.values());return e.json({targets:t})});b.post("/api/target-umur",async e=>{try{const t=await e.req.json(),{partNumber:a,targetUmurHari:s,jenisBarang:r,material:n,mesin:i}=t;return!a||!s?e.json({error:"Part number and target umur required"},400):(we.set(a,{partNumber:a,targetUmurHari:parseInt(s),jenisBarang:r,material:n,mesin:i,updatedAt:new Date().toISOString()}),e.json({success:!0,message:"Target umur saved successfully",data:we.get(a)}))}catch{return e.json({error:"Failed to save target umur"},500)}});b.get("/api/target-umur/:partNumber",e=>{const t=e.req.param("partNumber"),a=we.get(t);return a?e.json({...a,isDefault:!1}):e.json({partNumber:t,targetUmurHari:365,isDefault:!0})});b.post("/api/login",async e=>{try{const{username:t,password:a}=await e.req.json();if(t===et.username&&a===et.password){const s=`session_${Date.now()}_${Math.random().toString(36).substring(7)}`;return ye.set(s,{username:t,loginTime:new Date().toISOString(),expiresAt:new Date(Date.now()+480*60*1e3).toISOString()}),e.json({success:!0,message:"Login successful",sessionToken:s})}else return e.json({success:!1,message:"Username atau password salah"},401)}catch{return e.json({error:"Login failed"},500)}});b.post("/api/logout",async e=>{try{const t=e.req.header("Authorization"),a=t==null?void 0:t.replace("Bearer ","");return a&&ye.delete(a),e.json({success:!0,message:"Logout successful"})}catch{return e.json({error:"Logout failed"},500)}});b.get("/api/check-session",e=>{const t=e.req.header("Authorization"),a=t==null?void 0:t.replace("Bearer ","");if(!a||!ye.has(a))return e.json({valid:!1},401);const s=ye.get(a),r=new Date,n=new Date(s.expiresAt);return r>n?(ye.delete(a),e.json({valid:!1,message:"Session expired"},401)):e.json({valid:!0,username:s.username,expiresAt:s.expiresAt})});b.post("/api/save-gangguan",async e=>{try{const t=await e.req.json();console.log("💾 Saving gangguan form..."),console.log("📋 Form data received:",JSON.stringify(t).substring(0,200)+"...");const a=Ma();console.log("🏷️ Generated Nomor LH05:",a);const s={id:Date.now().toString(),nomorLH05:a,...t,createdAt:new Date().toISOString()};return M.push(s),console.log("✅ Gangguan saved successfully"),console.log("📊 Total gangguan now:",M.length),console.log("🗂️ Last 3 items:",M.slice(-3).map(r=>r.nomorLH05)),e.json({success:!0,message:"Form gangguan saved successfully",nomorLH05:a,data:s})}catch(t){return console.error("❌ Error saving gangguan:",t),e.json({error:"Failed to save gangguan"},500)}});b.get("/api/gangguan-transactions",e=>(console.log("🔍 GET /api/gangguan-transactions called"),console.log("📊 Total gangguan:",M.length),console.log("🗂️ Gangguan list:",M.map(t=>{var a;return{nomor:t.nomorLH05,unit:t.unitULD,kelompok:t.kelompokSPD,materials:((a=t.materials)==null?void 0:a.length)||0}})),e.json({gangguanTransactions:M})));b.get("/api/gangguan/:nomor",e=>{const t=e.req.param("nomor"),a=M.find(s=>s.nomorLH05===t);return a?e.json({gangguan:a}):e.json({error:"LH05 not found"},404)});b.get("/api/dashboard/gangguan",e=>{const t=e.req.query("kelompok")||"",a=e.req.query("tanggal")||"";let s=M;return t&&(s=s.filter(r=>r.kelompokSPD===t)),a&&(s=s.filter(r=>{var n;return(n=r.hariTanggal)==null?void 0:n.includes(a)})),e.json({data:s})});b.get("/api/kebutuhan-material",e=>{const t=e.req.query("status")||"",a=e.req.query("nomor")||"";let s=[];return M.forEach(r=>{r.materials&&Array.isArray(r.materials)&&r.materials.forEach(n=>{s.push({...n,nomorLH05:r.nomorLH05,unitULD:r.unitULD,lokasiTujuan:r.unitULD,tanggalGangguan:r.hariTanggal,kelompokSPD:r.kelompokSPD,status:n.status||"Pengadaan"})})}),t&&(s=s.filter(r=>r.status===t)),a&&(s=s.filter(r=>r.nomorLH05.includes(a))),e.json({materials:s})});b.post("/api/update-material-status",async e=>{var t;try{const{nomorLH05:a,partNumber:s,status:r}=await e.req.json(),n=M.find(c=>c.nomorLH05===a);if(!n)return e.json({error:"Gangguan not found"},404);const i=(t=n.materials)==null?void 0:t.find(c=>c.partNumber===s);return i?(i.status=r,i.updatedAt=new Date().toISOString(),e.json({success:!0,message:"Status updated",material:i})):e.json({error:"Material not found"},404)}catch{return e.json({error:"Failed to update status"},500)}});b.get("/",e=>e.html(Da()));b.get("/dashboard/stok",e=>e.html(Na()));b.get("/dashboard/umur",e=>e.html(Ra()));b.get("/dashboard/mutasi",e=>e.html(Oa()));b.get("/login",e=>e.html(Ia()));b.get("/form-gangguan",e=>e.html(Ca()));b.get("/dashboard/gangguan",e=>e.html(Ha()));b.get("/dashboard/kebutuhan-material",e=>e.html(Fa()));function Da(){return`
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sistem Inventaris Spare Part</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <style>
          .signature-pad {
            border: 2px dashed #cbd5e1;
            border-radius: 8px;
            cursor: crosshair;
          }
          .signature-pad:hover {
            border-color: #3b82f6;
          }
        </style>
    </head>
    <body class="bg-gray-50">
        <!-- Navigation -->
        <nav class="bg-blue-600 text-white p-4 shadow-lg">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-warehouse text-2xl"></i>
                    <span class="text-xl font-bold">Sistem Manajemen Material</span>
                </div>
                <div class="flex flex-wrap space-x-2 items-center">
                    <a href="/" class="px-3 py-2 bg-blue-700 rounded hover:bg-blue-800">
                        <i class="fas fa-plus mr-1"></i>Input Material
                    </a>
                    <a href="/form-gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exclamation-triangle mr-1"></i>Form Gangguan
                    </a>
                    <a href="/dashboard/stok" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-chart-bar mr-1"></i>Stok
                    </a>
                    <a href="/dashboard/umur" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-calendar-alt mr-1"></i>Umur
                    </a>
                    <a href="/dashboard/mutasi" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exchange-alt mr-1"></i>Mutasi
                    </a>
                    <a href="/dashboard/gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-tools mr-1"></i>Gangguan
                    </a>
                    <button onclick="logout()" class="px-3 py-2 bg-red-600 hover:bg-blue-700 rounded ml-4">
                        <i class="fas fa-sign-out-alt mr-1"></i>Logout
                    </button>
                </div>
            </div>
        </nav>

        <div class="min-h-screen py-8 px-4">
            <div class="max-w-5xl mx-auto">
                <!-- Header -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <h1 class="text-3xl font-bold text-gray-800 mb-2">
                        <i class="fas fa-clipboard-list text-blue-600 mr-3"></i>
                        Form Input Transaksi Material
                    </h1>
                    <p class="text-gray-600">Pengeluaran dan Penerimaan Gudang</p>
                </div>

                <!-- Form -->
                <form id="transactionForm" class="space-y-6">
                    <!-- Informasi Umum -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                            <i class="fas fa-info-circle text-blue-600 mr-2"></i>
                            INFORMASI UMUM
                        </h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Tanggal</label>
                                <input type="date" id="tanggal" required
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Jenis Transaksi</label>
                                <select id="jenisTransaksi" required
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                                    <option value="">-- Pilih Jenis --</option>
                                    <option value="Keluar (Pengeluaran Gudang)">Keluar (Pengeluaran Gudang)</option>
                                    <option value="Masuk (Penerimaan Gudang)">Masuk (Penerimaan Gudang)</option>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Lokasi Keluar/Asal</label>
                                <select id="lokasiAsal" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                                    <option value="">-- Pilih Lokasi --</option>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Lokasi Tujuan</label>
                                <select id="lokasiTujuan" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                                    <option value="">-- Pilih Lokasi --</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- Detail Material -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            <i class="fas fa-boxes text-blue-600 mr-2"></i>
                            Detail Material
                        </h2>
                        
                        <div id="materialList" class="space-y-4"></div>
                        
                        <button type="button" id="addMaterial" 
                            class="w-full mt-4 bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition flex items-center justify-center">
                            <i class="fas fa-plus mr-2"></i>
                            Tambah Baris Material
                        </button>
                    </div>

                    <!-- Penanggung Jawab -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            <i class="fas fa-user-check text-blue-600 mr-2"></i>
                            Penanggung Jawab dan Validasi
                        </h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Pemeriksa</label>
                                <select id="pemeriksa" required class="w-full px-4 py-2 border border-gray-300 rounded-lg mb-4">
                                    <option value="">-- Pilih Pemeriksa --</option>
                                </select>
                                
                                <label class="block text-sm font-medium text-gray-700 mb-2">Tanda Tangan Pemeriksa</label>
                                <canvas id="signaturePemeriksa" width="300" height="150" class="signature-pad w-full bg-gray-50"></canvas>
                                <button type="button" id="clearPemeriksa" class="mt-2 text-sm text-red-600 hover:text-red-700">
                                    <i class="fas fa-eraser mr-1"></i>Hapus
                                </button>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Penerima</label>
                                <select id="penerima" required class="w-full px-4 py-2 border border-gray-300 rounded-lg mb-4">
                                    <option value="">-- Pilih Penerima --</option>
                                </select>
                                
                                <label class="block text-sm font-medium text-gray-700 mb-2">Tanda Tangan Penerima</label>
                                <canvas id="signaturePenerima" width="300" height="150" class="signature-pad w-full bg-gray-50"></canvas>
                                <button type="button" id="clearPenerima" class="mt-2 text-sm text-red-600 hover:text-red-700">
                                    <i class="fas fa-eraser mr-1"></i>Hapus
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Submit -->
                    <div class="flex gap-4">
                        <button type="submit" 
                            class="flex-1 bg-green-600 text-white py-4 px-6 rounded-lg hover:bg-blue-700 transition text-lg font-semibold">
                            <i class="fas fa-save mr-2"></i>Simpan Transaksi
                        </button>
                        <button type="button" id="resetForm"
                            class="px-6 py-4 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition">
                            <i class="fas fa-undo mr-2"></i>Reset
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <script src="/static/auth-check.js"><\/script>
        <script src="/static/app.js"><\/script>
    </body>
    </html>
  `}function Na(){return`
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard Stok Material</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <nav class="bg-blue-600 text-white p-4 shadow-lg">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-chart-bar text-2xl"></i>
                    <span class="text-xl font-bold">Dashboard Stok Material</span>
                </div>
                <div class="flex flex-wrap space-x-2 items-center">
                    <a href="/" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-plus mr-1"></i>Input Material
                    </a>
                    <a href="/form-gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exclamation-triangle mr-1"></i>Form Gangguan
                    </a>
                    <a href="/dashboard/stok" class="px-3 py-2 bg-blue-700 rounded hover:bg-blue-800">
                        <i class="fas fa-chart-bar mr-1"></i>Stok
                    </a>
                    <a href="/dashboard/umur" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-calendar-alt mr-1"></i>Umur
                    </a>
                    <a href="/dashboard/mutasi" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exchange-alt mr-1"></i>Mutasi
                    </a>
                    <a href="/dashboard/gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-tools mr-1"></i>Gangguan
                    </a>
                    <a href="/dashboard/kebutuhan-material" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-clipboard-list mr-1"></i>Kebutuhan
                    </a>
                    <button onclick="logout()" class="px-3 py-2 bg-red-600 hover:bg-blue-700 rounded ml-4">
                        <i class="fas fa-sign-out-alt mr-1"></i>Logout
                    </button>
                </div>
            </div>
        </nav>

        <div class="flex">
            <!-- Sidebar Filter (Kiri) -->
            <div class="w-64 bg-white shadow-lg p-6 min-h-screen">
                <h2 class="text-xl font-bold mb-6 text-gray-800">
                    <i class="fas fa-filter mr-2 text-green-600"></i>
                    Filter Data
                </h2>
                
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium mb-2">Jenis Barang</label>
                        <div class="space-y-2">
                            <button onclick="filterJenis('MATERIAL HANDAL')" 
                                class="w-full text-left px-3 py-2 bg-blue-100 hover:bg-blue-200 rounded text-sm">
                                MATERIAL HANDAL
                            </button>
                            <button onclick="filterJenis('FILTER')" 
                                class="w-full text-left px-3 py-2 bg-green-100 hover:bg-green-200 rounded text-sm">
                                FILTER
                            </button>
                            <button onclick="filterJenis('MATERIAL BEKAS')" 
                                class="w-full text-left px-3 py-2 bg-yellow-100 hover:bg-yellow-200 rounded text-sm">
                                MATERIAL BEKAS
                            </button>
                            <button onclick="filterJenis('')" 
                                class="w-full text-left px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded text-sm">
                                SEMUA
                            </button>
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2">Cari Part Number</label>
                        <input type="text" id="searchPart" placeholder="Cari..." 
                            class="w-full px-3 py-2 border rounded-lg text-sm">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2">Filter Mesin</label>
                        <select id="filterMesin" class="w-full px-3 py-2 border rounded-lg text-sm">
                            <option value="">Semua</option>
                        </select>
                    </div>
                    
                    <div class="pt-4 border-t">
                        <button onclick="exportPDF()" class="w-full bg-green-600 text-white py-2 rounded hover:bg-blue-700 mb-2 text-sm">
                            <i class="fas fa-file-pdf mr-2"></i>PDF
                        </button>
                        <button onclick="exportExcel()" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 text-sm">
                            <i class="fas fa-file-excel mr-2"></i>Excel
                        </button>
                    </div>
                </div>
                
                <div class="mt-8 p-4 bg-green-50 rounded-lg">
                    <h3 class="font-semibold text-green-800 mb-2">
                        <i class="fas fa-info-circle mr-2"></i>
                        Status Stok
                    </h3>
                    <div class="space-y-2 text-sm">
                        <div class="flex items-center">
                            <span class="w-3 h-3 bg-red-500 rounded-full mr-2"></span>
                            <span>Habis (0)</span>
                        </div>
                        <div class="flex items-center">
                            <span class="w-3 h-3 bg-yellow-500 rounded-full mr-2"></span>
                            <span>Hampir Habis (≤10)</span>
                        </div>
                        <div class="flex items-center">
                            <span class="w-3 h-3 bg-green-500 rounded-full mr-2"></span>
                            <span>Tersedia (>10)</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Content (Kanan) -->
            <div class="flex-1 p-6">
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <h2 class="text-2xl font-bold text-gray-800">
                        <i class="fas fa-boxes mr-2 text-green-600"></i>
                        Daftar Stok Material
                    </h2>
                </div>

                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <table class="w-full">
                        <thead class="bg-blue-500 text-white">
                            <tr>
                                <th class="px-4 py-3 text-left">Part Number</th>
                                <th class="px-4 py-3 text-left">Jenis Barang</th>
                                <th class="px-4 py-3 text-left">Material</th>
                                <th class="px-4 py-3 text-left">Mesin</th>
                                <th class="px-4 py-3 text-center">Stok Masuk</th>
                                <th class="px-4 py-3 text-center">Stok Keluar</th>
                                <th class="px-4 py-3 text-center">Stok Akhir</th>
                                <th class="px-4 py-3 text-left">Unit</th>
                            </tr>
                        </thead>
                        <tbody id="stockTable">
                            <tr>
                                <td colspan="8" class="px-4 py-8 text-center text-gray-500">
                                    Belum ada data transaksi
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <script src="/static/auth-check.js"><\/script>
        <script src="/static/dashboard-stok.js"><\/script>
    </body>
    </html>
  `}function Ra(){return`
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard Umur Material</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <!-- Navigation -->
        <nav class="bg-blue-600 text-white p-4 shadow-lg">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-calendar-alt text-2xl"></i>
                    <span class="text-xl font-bold">Dashboard Umur Material</span>
                </div>
                <div class="flex flex-wrap space-x-2">
                    <a href="/" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-plus mr-1"></i>Input Material
                    </a>
                    <a href="/form-gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exclamation-triangle mr-1"></i>Form Gangguan
                    </a>
                    <a href="/dashboard/stok" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-chart-bar mr-1"></i>Stok
                    </a>
                    <a href="/dashboard/umur" class="px-3 py-2 bg-blue-700 rounded hover:bg-blue-800">
                        <i class="fas fa-calendar-alt mr-1"></i>Umur
                    </a>
                    <a href="/dashboard/mutasi" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exchange-alt mr-1"></i>Mutasi
                    </a>
                    <a href="/dashboard/gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-tools mr-1"></i>Gangguan
                    </a>
                    <a href="/dashboard/kebutuhan-material" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-clipboard-list mr-1"></i>Kebutuhan
                    </a>
                    <button onclick="logout()" class="px-3 py-2 bg-red-600 hover:bg-blue-700 rounded ml-4">
                        <i class="fas fa-sign-out-alt mr-1"></i>Logout
                    </button>
                </div>
            </div>
        </nav>

        <!-- Main Content with Sidebar -->
        <div class="flex">
            <!-- Sidebar Filter (Vertical) -->
            <aside class="w-80 bg-gray-900 shadow-lg min-h-screen p-6">
                <h2 class="text-2xl font-bold text-blue-400 mb-6 flex items-center">
                    <i class="fas fa-filter mr-2"></i>
                    Filter Material
                </h2>
                
                <div class="space-y-6">
                    <!-- Filter Lokasi -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-300 mb-3">
                            <i class="fas fa-map-marker-alt mr-2 text-pink-600"></i>
                            Lokasi
                        </label>
                        <select id="filterLokasi" class="w-full px-4 py-2 bg-gray-800 text-white border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500">
                            <option value="">Semua Lokasi</option>
                        </select>
                    </div>
                    
                    <!-- Filter Material -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-300 mb-3">
                            <i class="fas fa-box mr-2 text-pink-600"></i>
                            Material
                        </label>
                        <input type="text" id="filterMaterial" placeholder="Cari Material..." 
                            class="w-full px-4 py-2 bg-gray-800 text-white border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500">
                    </div>
                    
                    <!-- Filter S/N Mesin -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-300 mb-3">
                            <i class="fas fa-barcode mr-2 text-pink-600"></i>
                            S/N Mesin
                        </label>
                        <input type="text" id="filterSN" placeholder="Cari S/N Mesin..." 
                            class="w-full px-4 py-2 bg-gray-800 text-white border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500">
                    </div>

                    <!-- Status Legend -->
                    <div class="mt-8 p-4 bg-white rounded-lg shadow-md">
                        <h3 class="font-semibold text-pink-800 mb-3">
                            <i class="fas fa-info-circle mr-2"></i>
                            Keterangan Status
                        </h3>
                        <div class="space-y-2 text-sm text-gray-700">
                            <div class="flex items-center">
                                <span class="inline-block w-4 h-4 bg-red-100 border-2 border-red-500 rounded mr-2"></span>
                                <span>Perlu Diganti (Lewat Target)</span>
                            </div>
                            <div class="flex items-center">
                                <span class="inline-block w-4 h-4 bg-yellow-100 border-2 border-yellow-500 rounded mr-2"></span>
                                <span>Mendekati Batas (≤20 hari)</span>
                            </div>
                            <div class="flex items-center">
                                <span class="inline-block w-4 h-4 bg-green-100 border-2 border-green-500 rounded mr-2"></span>
                                <span>Terpasang (Normal)</span>
                            </div>
                        </div>
                    </div>
                </div>
            </aside>

            <!-- Main Content Area -->
            <main class="flex-1 p-6">
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-blue-500 text-white">
                                <tr>
                                    <th class="px-4 py-3 text-left">S/N Mesin</th>
                                    <th class="px-4 py-3 text-left">Part Number</th>
                                    <th class="px-4 py-3 text-left">Material</th>
                                    <th class="px-4 py-3 text-left">Tanggal Pasang</th>
                                    <th class="px-4 py-3 text-center">Umur (Hari)</th>
                                    <th class="px-4 py-3 text-center">Target (Hari)</th>
                                    <th class="px-4 py-3 text-center">Sisa (Hari)</th>
                                    <th class="px-4 py-3 text-left">Lokasi</th>
                                    <th class="px-4 py-3 text-center">Status</th>
                                    <th class="px-4 py-3 text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody id="ageTable">
                                <tr>
                                    <td colspan="10" class="px-4 py-8 text-center text-gray-500">
                                        <i class="fas fa-spinner fa-spin text-3xl mb-3"></i>
                                        <p>Memuat data...</p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>

        <script src="/static/auth-check.js"><\/script>
        <script src="/static/dashboard-umur.js"><\/script>
    </body>
    </html>
  `}function Oa(){return`
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard Mutasi Material</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <!-- Navigation -->
        <nav class="bg-blue-600 text-white p-4 shadow-lg">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-exchange-alt text-2xl"></i>
                    <span class="text-xl font-bold">Dashboard Mutasi Material</span>
                </div>
                <div class="flex flex-wrap space-x-2">
                    <a href="/" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-plus mr-1"></i>Input Material
                    </a>
                    <a href="/form-gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exclamation-triangle mr-1"></i>Form Gangguan
                    </a>
                    <a href="/dashboard/stok" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-chart-bar mr-1"></i>Stok
                    </a>
                    <a href="/dashboard/umur" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-calendar-alt mr-1"></i>Umur
                    </a>
                    <a href="/dashboard/mutasi" class="px-3 py-2 bg-blue-700 rounded hover:bg-blue-800">
                        <i class="fas fa-exchange-alt mr-1"></i>Mutasi
                    </a>
                    <a href="/dashboard/gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-tools mr-1"></i>Gangguan
                    </a>
                    <a href="/dashboard/kebutuhan-material" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-clipboard-list mr-1"></i>Kebutuhan
                    </a>
                    <button onclick="logout()" class="px-3 py-2 bg-red-600 hover:bg-blue-700 rounded ml-4">
                        <i class="fas fa-sign-out-alt mr-1"></i>Logout
                    </button>
                </div>
            </div>
        </nav>

        <!-- Main Content with Sidebar -->
        <div class="flex">
            <!-- Sidebar Filter (Vertical) -->
            <aside class="w-80 bg-gray-900 shadow-lg min-h-screen p-6">
                <h2 class="text-2xl font-bold text-blue-400 mb-6 flex items-center">
                    <i class="fas fa-filter mr-2"></i>
                    Filter Mutasi
                </h2>
                
                <div class="space-y-6">
                    <!-- Filter Tanggal -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-300 mb-3">
                            <i class="fas fa-calendar mr-2 text-cyan-600"></i>
                            Tanggal
                        </label>
                        <input type="date" id="filterTanggal" 
                            class="w-full px-4 py-2 bg-gray-800 text-white border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500">
                    </div>
                    
                    <!-- Filter Nomor BA -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-300 mb-3">
                            <i class="fas fa-file-alt mr-2 text-cyan-600"></i>
                            Nomor BA
                        </label>
                        <input type="text" id="filterNomorBA" placeholder="Cari Nomor BA..." 
                            class="w-full px-4 py-2 bg-gray-800 text-white border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500">
                    </div>

                    <!-- Export Button -->
                    <div class="mt-8">
                        <button onclick="exportAllBA()" class="w-full bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 font-semibold">
                            <i class="fas fa-file-export mr-2"></i>
                            Export Semua BA
                        </button>
                    </div>

                    <!-- Info Box -->
                    <div class="mt-8 p-4 bg-white rounded-lg shadow-md">
                        <h3 class="font-semibold text-cyan-800 mb-3">
                            <i class="fas fa-info-circle mr-2"></i>
                            Informasi
                        </h3>
                        <div class="space-y-2 text-sm text-gray-700">
                            <p>• Klik Nomor BA untuk melihat detail</p>
                            <p>• Status Terkirim untuk export BA</p>
                            <p>• Filter berdasarkan tanggal dan BA</p>
                        </div>
                    </div>
                </div>
            </aside>

            <!-- Main Content Area -->
            <main class="flex-1 p-6">
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-blue-500 text-white">
                                <tr>
                                    <th class="px-4 py-3 text-left">Nomor BA</th>
                                    <th class="px-4 py-3 text-left">Tanggal</th>
                                    <th class="px-4 py-3 text-left">Jenis Transaksi</th>
                                    <th class="px-4 py-3 text-left">Part Number</th>
                                    <th class="px-4 py-3 text-center">Jumlah</th>
                                    <th class="px-4 py-3 text-left">Lokasi Keluar</th>
                                    <th class="px-4 py-3 text-left">Lokasi Tujuan</th>
                                    <th class="px-4 py-3 text-left">Pemeriksa</th>
                                    <th class="px-4 py-3 text-left">Penerima</th>
                                    <th class="px-4 py-3 text-center">Status BA</th>
                                </tr>
                            </thead>
                            <tbody id="mutasiTable">
                                <tr>
                                    <td colspan="10" class="px-4 py-8 text-center text-gray-500">
                                        <i class="fas fa-spinner fa-spin text-3xl mb-3"></i>
                                        <p>Memuat data...</p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>

        <script src="/static/auth-check.js"><\/script>
        <script src="/static/dashboard-mutasi.js"><\/script>
    </body>
    </html>
  `}function Ca(){return`
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Form Gangguan dan Permintaan Material</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <style>
          .signature-pad {
            border: 2px dashed #cbd5e1;
            border-radius: 8px;
            cursor: crosshair;
          }
          .signature-pad:hover {
            border-color: #3b82f6;
          }
        </style>
    </head>
    <body class="bg-gray-50">
        <!-- Navigation -->
        <nav class="bg-blue-600 text-white p-4 shadow-lg">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-exclamation-triangle text-2xl"></i>
                    <span class="text-xl font-bold">Form Gangguan dan Permintaan Material</span>
                </div>
                <div class="flex flex-wrap space-x-2">
                    <a href="/" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-plus mr-1"></i>Input Material
                    </a>
                    <a href="/form-gangguan" class="px-3 py-2 bg-blue-700 rounded hover:bg-blue-800">
                        <i class="fas fa-exclamation-triangle mr-1"></i>Form Gangguan
                    </a>
                    <a href="/dashboard/stok" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-chart-bar mr-1"></i>Stok
                    </a>
                    <a href="/dashboard/umur" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-calendar-alt mr-1"></i>Umur
                    </a>
                    <a href="/dashboard/mutasi" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exchange-alt mr-1"></i>Mutasi
                    </a>
                    <a href="/dashboard/gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-tools mr-1"></i>Gangguan
                    </a>
                </div>
            </div>
        </nav>

        <div class="min-h-screen py-8 px-4">
            <div class="max-w-6xl mx-auto">
                <!-- Header -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <h1 class="text-3xl font-bold text-gray-800 mb-2">
                        <i class="fas fa-file-alt text-red-600 mr-3"></i>
                        Form Gangguan dan Permintaan Material
                    </h1>
                    <p class="text-gray-600">Berita Acara LH05</p>
                </div>

                <!-- Form -->
                <form id="gangguanForm" class="space-y-6">
                    <!-- BA LH05 Number (Auto) -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            <i class="fas fa-hashtag text-red-600 mr-2"></i>
                            Nomor BA LH05 (Auto)
                        </h2>
                        <div class="bg-gray-100 p-4 rounded-lg">
                            <p class="text-sm text-gray-600 mb-2">Nomor akan di-generate otomatis:</p>
                            <p class="text-2xl font-bold text-red-600">Format: XXX/ND KAL 2/LH05/TAHUN</p>
                            <p class="text-sm text-gray-500 mt-2">Contoh: 001/ND KAL 2/LH05/2025</p>
                        </div>
                    </div>

                    <!-- 1. Hari/Tanggal/Jam Kejadian -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            1. Hari/Tanggal/Jam Kejadian
                        </h2>
                        <input type="datetime-local" id="hariTanggal" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500">
                    </div>

                    <!-- Unit/ULD -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            <i class="fas fa-building text-red-600 mr-2"></i>
                            Unit / ULD
                        </h2>
                        <select id="unitULD" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500">
                            <option value="">-- Pilih Unit/ULD --</option>
                        </select>
                    </div>

                    <!-- 2. Kelompok SPD yang rusak -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            2. Kelompok SPD yang rusak
                        </h2>
                        <select id="kelompokSPD" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500">
                            <option value="">-- Pilih Kelompok SPD --</option>
                            <option value="MEKANIK">MEKANIK</option>
                            <option value="ELEKTRIK">ELEKTRIK</option>
                        </select>
                    </div>

                    <!-- 3-6. Isian Manual -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            Analisa Gangguan
                        </h2>
                        
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    3. Komponen yang rusak
                                </label>
                                <input type="text" id="komponenRusak" required
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    4. Gejala yang timbul
                                </label>
                                <textarea id="gejala" required rows="3"
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    5. Uraian kejadian
                                </label>
                                <textarea id="uraianKejadian" required rows="3"
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    6. Analisa penyebab
                                </label>
                                <textarea id="analisaPenyebab" required rows="3"
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    7. Kesimpulan kerusakan
                                </label>
                                <textarea id="kesimpulan" required rows="3"
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- 8. Akibat terhadap sistem pembangkit -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            8. Akibat terhadap sistem pembangkit
                        </h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    Beban Puncak (MW)
                                </label>
                                <input type="number" id="bebanPuncak" step="0.01" required
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    Daya Mampu (MW)
                                </label>
                                <input type="number" id="dayaMampu" step="0.01" required
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    Status Pemadaman
                                </label>
                                <select id="pemadaman" required
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                                    <option value="">-- Pilih Status --</option>
                                    <option value="NORMAL">NORMAL</option>
                                    <option value="SIAGA">SIAGA</option>
                                    <option value="DEFISIT">DEFISIT</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- 9-10. Tindakan -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            Tindakan dan Rencana
                        </h2>
                        
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    9. Tindakan penanggulangan
                                </label>
                                <textarea id="tindakanPenanggulangan" required rows="3"
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    10. Rencana perbaikan
                                </label>
                                <textarea id="rencanaPerbaikan" required rows="3"
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- 11. Kebutuhan Material -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            <i class="fas fa-boxes text-red-600 mr-2"></i>
                            11. Kebutuhan Material
                        </h2>
                        
                        <div id="materialListGangguan" class="space-y-4"></div>
                        
                        <button type="button" id="addMaterialGangguan" 
                            class="w-full mt-4 bg-red-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition flex items-center justify-center">
                            <i class="fas fa-plus mr-2"></i>
                            Tambah Material
                        </button>
                    </div>

                    <!-- 12. TTD Digital -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            <i class="fas fa-signature text-red-600 mr-2"></i>
                            12. Tanda Tangan Digital Pelapor
                        </h2>
                        
                        <div class="max-w-md mx-auto">
                            <label class="block text-sm font-medium text-gray-300 mb-2">Nama Pelapor</label>
                            <input type="text" id="namaPelapor" required placeholder="Nama Pelapor"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg mb-4">
                            
                            <label class="block text-sm font-medium text-gray-300 mb-2">Tanda Tangan Pelapor</label>
                            <canvas id="signaturePelapor" width="400" height="200" class="signature-pad w-full bg-gray-50"></canvas>
                            <button type="button" id="clearPelapor" class="mt-2 text-sm text-red-600 hover:text-red-700">
                                <i class="fas fa-eraser mr-1"></i>Hapus Tanda Tangan
                            </button>
                        </div>
                    </div>

                    <!-- Submit -->
                    <div class="flex gap-4">
                        <button type="submit" 
                            class="flex-1 bg-green-600 text-white py-4 px-6 rounded-lg hover:bg-blue-700 transition text-lg font-semibold">
                            <i class="fas fa-save mr-2"></i>Simpan Form Gangguan
                        </button>
                        <button type="button" id="resetFormGangguan"
                            class="px-6 py-4 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition">
                            <i class="fas fa-undo mr-2"></i>Reset
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <script src="/static/form-gangguan.js"><\/script>
    </body>
    </html>
  `}function Ia(){return`
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login - Sistem Manajemen Material</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gradient-to-br from-blue-500 to-blue-700 min-h-screen flex items-center justify-center">
        <div class="max-w-md w-full mx-4">
            <!-- Login Card -->
            <div class="bg-white rounded-2xl shadow-2xl p-8">
                <!-- Header -->
                <div class="text-center mb-8">
                    <div class="bg-blue-600 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-warehouse text-4xl text-white"></i>
                    </div>
                    <h1 class="text-3xl font-bold text-gray-800 mb-2">Sistem Manajemen Material</h1>
                    <p class="text-gray-600">Silakan login untuk melanjutkan</p>
                </div>

                <!-- Error Message -->
                <div id="errorMessage" class="hidden bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded">
                    <div class="flex items-center">
                        <i class="fas fa-exclamation-circle mr-2"></i>
                        <span id="errorText">Username atau password salah</span>
                    </div>
                </div>

                <!-- Login Form -->
                <form id="loginForm" class="space-y-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-300 mb-2">
                            <i class="fas fa-user mr-2 text-blue-600"></i>Username
                        </label>
                        <input type="text" id="username" required
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                            placeholder="Masukkan username">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-300 mb-2">
                            <i class="fas fa-lock mr-2 text-blue-600"></i>Password
                        </label>
                        <div class="relative">
                            <input type="password" id="password" required
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                placeholder="Masukkan password">
                            <button type="button" id="togglePassword" 
                                class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <button type="submit" id="loginButton"
                        class="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition font-semibold text-lg flex items-center justify-center">
                        <i class="fas fa-sign-in-alt mr-2"></i>
                        <span>Login</span>
                    </button>
                </form>

                <!-- Public Access Link -->
                <div class="mt-8 pt-6 border-t border-gray-200 text-center">
                    <p class="text-gray-600 mb-3">Akses Publik:</p>
                    <a href="/form-gangguan" 
                        class="inline-flex items-center text-blue-600 hover:text-blue-700 font-semibold">
                        <i class="fas fa-exclamation-triangle mr-2"></i>
                        Form Gangguan dan Permintaan Material
                        <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            </div>

            <!-- Footer -->
            <div class="text-center mt-6 text-white">
                <p class="text-sm opacity-80">PT PLN (Persero) Unit Induk Wilayah Kalimantan Selatan & Tengah</p>
            </div>
        </div>

        <script>
          // Toggle password visibility
          document.getElementById('togglePassword').addEventListener('click', function() {
            const passwordInput = document.getElementById('password')
            const icon = this.querySelector('i')
            
            if (passwordInput.type === 'password') {
              passwordInput.type = 'text'
              icon.classList.remove('fa-eye')
              icon.classList.add('fa-eye-slash')
            } else {
              passwordInput.type = 'password'
              icon.classList.remove('fa-eye-slash')
              icon.classList.add('fa-eye')
            }
          })

          // Login form submit
          document.getElementById('loginForm').addEventListener('submit', async function(e) {
            e.preventDefault()
            
            const username = document.getElementById('username').value
            const password = document.getElementById('password').value
            const button = document.getElementById('loginButton')
            const errorDiv = document.getElementById('errorMessage')
            
            // Disable button
            button.disabled = true
            button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Loading...'
            
            try {
              const response = await fetch('/api/login', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
              })
              
              const data = await response.json()
              
              if (data.success) {
                // Save session token
                localStorage.setItem('sessionToken', data.sessionToken)
                
                // Show success and redirect
                button.innerHTML = '<i class="fas fa-check mr-2"></i>Login Berhasil!'
                button.classList.remove('bg-blue-600', 'hover:bg-blue-700')
                button.classList.add('bg-green-600')
                
                setTimeout(() => {
                  window.location.href = '/'
                }, 500)
              } else {
                // Show error
                errorDiv.classList.remove('hidden')
                document.getElementById('errorText').textContent = data.message || 'Login gagal'
                
                // Reset button
                button.disabled = false
                button.innerHTML = '<i class="fas fa-sign-in-alt mr-2"></i>Login'
              }
            } catch (error) {
              console.error('Login error:', error)
              errorDiv.classList.remove('hidden')
              document.getElementById('errorText').textContent = 'Terjadi kesalahan sistem'
              
              // Reset button
              button.disabled = false
              button.innerHTML = '<i class="fas fa-sign-in-alt mr-2"></i>Login'
            }
          })
        <\/script>
    </body>
    </html>
  `}function Fa(){return`
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard Kebutuhan Material</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <nav class="bg-blue-600 text-white p-4 shadow-lg">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-clipboard-list text-2xl"></i>
                    <span class="text-xl font-bold">Dashboard Kebutuhan Material</span>
                </div>
                <div class="flex flex-wrap space-x-2 items-center">
                    <a href="/" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-plus mr-1"></i>Input Material
                    </a>
                    <a href="/form-gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exclamation-triangle mr-1"></i>Form Gangguan
                    </a>
                    <a href="/dashboard/stok" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-chart-bar mr-1"></i>Stok
                    </a>
                    <a href="/dashboard/umur" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-calendar-alt mr-1"></i>Umur
                    </a>
                    <a href="/dashboard/mutasi" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exchange-alt mr-1"></i>Mutasi
                    </a>
                    <a href="/dashboard/gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-tools mr-1"></i>Gangguan
                    </a>
                    <a href="/dashboard/kebutuhan-material" class="px-3 py-2 bg-blue-700 rounded hover:bg-blue-800">
                        <i class="fas fa-clipboard-list mr-1"></i>Kebutuhan
                    </a>
                    <button onclick="logout()" class="px-3 py-2 bg-red-600 hover:bg-blue-700 rounded ml-4">
                        <i class="fas fa-sign-out-alt mr-1"></i>Logout
                    </button>
                </div>
            </div>
        </nav>

        <div class="flex">
            <!-- Sidebar Filter (Kiri) -->
            <div class="w-64 bg-gray-900 shadow-lg p-6 min-h-screen">
                <h2 class="text-xl font-bold mb-6 text-white">
                    <i class="fas fa-filter mr-2 text-blue-400"></i>
                    Filter Data
                </h2>
                
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Filter Status</label>
                        <select id="filterStatus" class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                            <option value="">Semua Status</option>
                            <option value="Pengadaan">Pengadaan</option>
                            <option value="Tunda">Tunda</option>
                            <option value="Reject">Reject</option>
                            <option value="Terkirim">Terkirim</option>
                            <option value="Tersedia">Tersedia</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Filter Mesin</label>
                        <select id="filterMesin" class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                            <option value="">Semua Mesin</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Filter Unit</label>
                        <select id="filterUnit" class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                            <option value="">Semua Unit</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Cari Nomor LH05</label>
                        <input type="text" id="searchNomor" placeholder="Cari nomor..." 
                            class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                    </div>
                    
                    <button onclick="applyFilters()" class="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">
                        <i class="fas fa-search mr-2"></i>Terapkan Filter
                    </button>
                    
                    <button onclick="resetFilters()" class="w-full bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400">
                        <i class="fas fa-undo mr-2"></i>Reset Filter
                    </button>
                </div>
                
                <div class="mt-8 p-4 bg-purple-50 rounded-lg">
                    <h3 class="font-semibold text-purple-800 mb-2">
                        <i class="fas fa-info-circle mr-2"></i>
                        Statistik
                    </h3>
                    <div class="space-y-2 text-sm">
                        <div class="flex justify-between">
                            <span>Total Material:</span>
                            <span id="totalMaterial" class="font-bold">0</span>
                        </div>
                        <div class="flex justify-between">
                            <span>Pengadaan:</span>
                            <span id="totalPengadaan" class="font-bold text-blue-600">0</span>
                        </div>
                        <div class="flex justify-between">
                            <span>Tunda:</span>
                            <span id="totalTunda" class="font-bold text-yellow-600">0</span>
                        </div>
                        <div class="flex justify-between">
                            <span>Reject:</span>
                            <span id="totalReject" class="font-bold text-red-600">0</span>
                        </div>
                        <div class="flex justify-between">
                            <span>Terkirim:</span>
                            <span id="totalTerkirim" class="font-bold text-green-600">0</span>
                        </div>
                        <div class="flex justify-between">
                            <span>Tersedia:</span>
                            <span id="totalTersedia" class="font-bold text-purple-600">0</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Content (Kanan) -->
            <div class="flex-1 p-6">
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <div class="flex justify-between items-center">
                        <h2 class="text-2xl font-bold text-gray-800">
                            <i class="fas fa-boxes mr-2 text-purple-600"></i>
                            Kebutuhan Material
                        </h2>
                        <button onclick="exportExcel()" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                            <i class="fas fa-file-excel mr-2"></i>Export Excel
                        </button>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <table class="w-full">
                        <thead class="bg-blue-500 text-white">
                            <tr>
                                <th class="px-4 py-3 text-center">No</th>
                                <th class="px-4 py-3 text-left">Nomor LH05</th>
                                <th class="px-4 py-3 text-left">Part Number</th>
                                <th class="px-4 py-3 text-left">Material</th>
                                <th class="px-4 py-3 text-left">Mesin</th>
                                <th class="px-4 py-3 text-center">Jumlah</th>
                                <th class="px-4 py-3 text-left">Unit/Lokasi Tujuan</th>
                                <th class="px-4 py-3 text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody id="kebutuhanTable">
                            <tr>
                                <td colspan="8" class="px-4 py-8 text-center text-gray-500">
                                    Belum ada data kebutuhan material
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <script src="/static/auth-check.js"><\/script>
        <script src="/static/dashboard-kebutuhan.js"><\/script>
    </body>
    </html>
  `}function Ha(){return`
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard Gangguan dan Permintaan Material</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <nav class="bg-blue-600 text-white p-4 shadow-lg">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-tools text-2xl"></i>
                    <span class="text-xl font-bold">Dashboard Gangguan dan Permintaan Material</span>
                </div>
                <div class="flex flex-wrap space-x-2">
                    <a href="/" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-plus mr-1"></i>Input Material
                    </a>
                    <a href="/form-gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exclamation-triangle mr-1"></i>Form Gangguan
                    </a>
                    <a href="/dashboard/stok" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-chart-bar mr-1"></i>Stok
                    </a>
                    <a href="/dashboard/umur" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-calendar-alt mr-1"></i>Umur
                    </a>
                    <a href="/dashboard/mutasi" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exchange-alt mr-1"></i>Mutasi
                    </a>
                    <a href="/dashboard/gangguan" class="px-3 py-2 bg-blue-700 rounded hover:bg-blue-800">
                        <i class="fas fa-tools mr-1"></i>Gangguan
                    </a>
                    <a href="/dashboard/kebutuhan-material" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-clipboard-list mr-1"></i>Kebutuhan
                    </a>
                    <button onclick="logout()" class="px-3 py-2 bg-red-600 hover:bg-blue-700 rounded ml-4">
                        <i class="fas fa-sign-out-alt mr-1"></i>Logout
                    </button>
                </div>
            </div>
        </nav>

        <div class="flex">
            <!-- Sidebar Filter (Kiri) -->
            <div class="w-64 bg-gray-900 shadow-lg p-6 min-h-screen">
                <h2 class="text-xl font-bold mb-6 text-white">
                    <i class="fas fa-filter mr-2 text-blue-400"></i>
                    Filter Data
                </h2>
                
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Kelompok SPD</label>
                        <select id="filterKelompok" class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                            <option value="">Semua</option>
                            <option value="MEKANIK">MEKANIK</option>
                            <option value="ELEKTRIK">ELEKTRIK</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Tanggal</label>
                        <input type="date" id="filterTanggal" class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Status Pemadaman</label>
                        <select id="filterPemadaman" class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                            <option value="">Semua</option>
                            <option value="NORMAL">NORMAL</option>
                            <option value="SIAGA">SIAGA</option>
                            <option value="DEFISIT">DEFISIT</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Filter Unit</label>
                        <select id="filterUnit" class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                            <option value="">Semua Unit</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Cari Nomor LH05</label>
                        <input type="text" id="searchNomor" placeholder="001/ND KAL 2/LH05/2025" 
                            class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                    </div>
                    
                    <button onclick="applyFilters()" class="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">
                        <i class="fas fa-search mr-2"></i>Terapkan Filter
                    </button>
                    
                    <button onclick="resetFilters()" class="w-full bg-gray-700 text-white py-2 rounded-lg hover:bg-gray-600">
                        <i class="fas fa-undo mr-2"></i>Reset Filter
                    </button>
                </div>
                
                <div class="mt-8 p-4 bg-gray-800 rounded-lg">
                    <h3 class="font-semibold text-blue-400 mb-2">
                        <i class="fas fa-info-circle mr-2"></i>
                        Statistik
                    </h3>
                    <div class="space-y-2 text-sm">
                        <div class="flex justify-between">
                            <span class="text-gray-300">Total Gangguan:</span>
                            <span class="text-gray-300" id="totalGangguan" class="font-bold">0</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-300">Mekanik:</span>
                            <span class="text-gray-300" id="totalMekanik" class="font-bold">0</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-300">Elektrik:</span>
                            <span class="text-gray-300" id="totalElektrik" class="font-bold">0</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Content (Kanan) -->
            <div class="flex-1 p-6">
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <div class="flex justify-between items-center">
                        <h2 class="text-2xl font-bold text-gray-800">
                            <i class="fas fa-list-ul mr-2 text-blue-600"></i>
                            Daftar Gangguan dan Permintaan Material
                        </h2>
                        <button onclick="exportAllLH05()" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                            <i class="fas fa-file-export mr-2"></i>Export All
                        </button>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <table class="w-full">
                        <thead class="bg-blue-500 text-white">
                            <tr>
                                <th class="px-4 py-3 text-left">Nomor LH05</th>
                                <th class="px-4 py-3 text-left">Tanggal Kejadian</th>
                                <th class="px-4 py-3 text-left">Kelompok SPD</th>
                                <th class="px-4 py-3 text-left">Komponen Rusak</th>
                                <th class="px-4 py-3 text-center">Beban (MW)</th>
                                <th class="px-4 py-3 text-center">Status</th>
                                <th class="px-4 py-3 text-center">Material</th>
                                <th class="px-4 py-3 text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="gangguanTable">
                            <tr>
                                <td colspan="8" class="px-4 py-8 text-center text-gray-500">
                                    <div class="mb-4">
                                        <i class="fas fa-spinner fa-spin text-4xl text-blue-500 mb-3"></i>
                                        <p class="text-lg font-semibold">Memuat data gangguan...</p>
                                        <p class="text-sm text-gray-400 mt-2">Jika data tidak muncul dalam 5 detik, refresh halaman (F5)</p>
                                    </div>
                                    <div id="debugInfo" class="mt-4 p-4 bg-yellow-50 border-l-4 border-yellow-400 text-left text-sm">
                                        <p class="font-semibold mb-2"><i class="fas fa-info-circle mr-2"></i>Debug Info:</p>
                                        <p>⏳ Loading... mohon tunggu</p>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <script src="/static/auth-check.js"><\/script>
        <script src="/static/dashboard-gangguan.js"><\/script>
        <script>
          // Force load data after auth check completes
          window.addEventListener('load', function() {
            console.log('🔥 FORCE LOADING dashboard gangguan data...')
            setTimeout(function() {
              if (typeof loadDashboardData === 'function') {
                console.log('✅ Calling loadDashboardData() manually')
                loadDashboardData()
              } else {
                console.error('❌ loadDashboardData function not found!')
              }
            }, 1000)
          })
        <\/script>
    </body>
    </html>
  `}const at=new Tt,_a=Object.assign({"/src/index.tsx":b});let St=!1;for(const[,e]of Object.entries(_a))e&&(at.all("*",t=>{let a;try{a=t.executionCtx}catch{}return e.fetch(t.req.raw,t.env,a)}),at.notFound(t=>{let a;try{a=t.executionCtx}catch{}return e.fetch(t.req.raw,t.env,a)}),St=!0);if(!St)throw new Error("Can't import modules from ['/src/index.ts','/src/index.tsx','/app/server.ts']");export{at as default};
