var Dt=Object.defineProperty;var $e=e=>{throw TypeError(e)};var Pt=(e,t,a)=>t in e?Dt(e,t,{enumerable:!0,configurable:!0,writable:!0,value:a}):e[t]=a;var p=(e,t,a)=>Pt(e,typeof t!="symbol"?t+"":t,a),He=(e,t,a)=>t.has(e)||$e("Cannot "+a);var o=(e,t,a)=>(He(e,t,"read from private field"),a?a.call(e):t.get(e)),m=(e,t,a)=>t.has(e)?$e("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(e):t.set(e,a),g=(e,t,a,s)=>(He(e,t,"write to private field"),s?s.call(e,a):t.set(e,a),a),x=(e,t,a)=>(He(e,t,"access private method"),a);var ze=(e,t,a,s)=>({set _(r){g(e,t,r,a)},get _(){return o(e,t,s)}});var Je=(e,t,a)=>(s,r)=>{let n=-1;return i(0);async function i(d){if(d<=n)throw new Error("next() called multiple times");n=d;let l,c=!1,u;if(e[d]?(u=e[d][0][0],s.req.routeIndex=d):u=d===e.length&&r||void 0,u)try{l=await u(s,()=>i(d+1))}catch(h){if(h instanceof Error&&t)s.error=h,l=await t(h,s),c=!0;else throw h}else s.finalized===!1&&a&&(l=await a(s));return l&&(s.finalized===!1||c)&&(s.res=l),s}},Lt=Symbol(),Nt=async(e,t=Object.create(null))=>{const{all:a=!1,dot:s=!1}=t,n=(e instanceof gt?e.raw.headers:e.headers).get("Content-Type");return n!=null&&n.startsWith("multipart/form-data")||n!=null&&n.startsWith("application/x-www-form-urlencoded")?Rt(e,{all:a,dot:s}):{}};async function Rt(e,t){const a=await e.formData();return a?Ct(a,t):{}}function Ct(e,t){const a=Object.create(null);return e.forEach((s,r)=>{t.all||r.endsWith("[]")?It(a,r,s):a[r]=s}),t.dot&&Object.entries(a).forEach(([s,r])=>{s.includes(".")&&(Ot(a,s,r),delete a[s])}),a}var It=(e,t,a)=>{e[t]!==void 0?Array.isArray(e[t])?e[t].push(a):e[t]=[e[t],a]:t.endsWith("[]")?e[t]=[a]:e[t]=a},Ot=(e,t,a)=>{let s=e;const r=t.split(".");r.forEach((n,i)=>{i===r.length-1?s[n]=a:((!s[n]||typeof s[n]!="object"||Array.isArray(s[n])||s[n]instanceof File)&&(s[n]=Object.create(null)),s=s[n])})},ot=e=>{const t=e.split("/");return t[0]===""&&t.shift(),t},Ft=e=>{const{groups:t,path:a}=Ht(e),s=ot(a);return _t(s,t)},Ht=e=>{const t=[];return e=e.replace(/\{[^}]+\}/g,(a,s)=>{const r=`@${s}`;return t.push([r,a]),r}),{groups:t,path:e}},_t=(e,t)=>{for(let a=t.length-1;a>=0;a--){const[s]=t[a];for(let r=e.length-1;r>=0;r--)if(e[r].includes(s)){e[r]=e[r].replace(s,t[a][1]);break}}return e},Ee={},Bt=(e,t)=>{if(e==="*")return"*";const a=e.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);if(a){const s=`${e}#${t}`;return Ee[s]||(a[2]?Ee[s]=t&&t[0]!==":"&&t[0]!=="*"?[s,a[1],new RegExp(`^${a[2]}(?=/${t})`)]:[e,a[1],new RegExp(`^${a[2]}$`)]:Ee[s]=[e,a[1],!0]),Ee[s]}return null},Ue=(e,t)=>{try{return t(e)}catch{return e.replace(/(?:%[0-9A-Fa-f]{2})+/g,a=>{try{return t(a)}catch{return a}})}},Kt=e=>Ue(e,decodeURI),ct=e=>{const t=e.url,a=t.indexOf("/",t.indexOf(":")+4);let s=a;for(;s<t.length;s++){const r=t.charCodeAt(s);if(r===37){const n=t.indexOf("?",s),i=t.slice(a,n===-1?void 0:n);return Kt(i.includes("%25")?i.replace(/%25/g,"%2525"):i)}else if(r===63)break}return t.slice(a,s)},Ut=e=>{const t=ct(e);return t.length>1&&t.at(-1)==="/"?t.slice(0,-1):t},re=(e,t,...a)=>(a.length&&(t=re(t,...a)),`${(e==null?void 0:e[0])==="/"?"":"/"}${e}${t==="/"?"":`${(e==null?void 0:e.at(-1))==="/"?"":"/"}${(t==null?void 0:t[0])==="/"?t.slice(1):t}`}`),dt=e=>{if(e.charCodeAt(e.length-1)!==63||!e.includes(":"))return null;const t=e.split("/"),a=[];let s="";return t.forEach(r=>{if(r!==""&&!/\:/.test(r))s+="/"+r;else if(/\:/.test(r))if(/\?/.test(r)){a.length===0&&s===""?a.push("/"):a.push(s);const n=r.replace("?","");s+="/"+n,a.push(s)}else s+="/"+r}),a.filter((r,n,i)=>i.indexOf(r)===n)},_e=e=>/[%+]/.test(e)?(e.indexOf("+")!==-1&&(e=e.replace(/\+/g," ")),e.indexOf("%")!==-1?Ue(e,ht):e):e,ut=(e,t,a)=>{let s;if(!a&&t&&!/[%+]/.test(t)){let i=e.indexOf("?",8);if(i===-1)return;for(e.startsWith(t,i+1)||(i=e.indexOf(`&${t}`,i+1));i!==-1;){const d=e.charCodeAt(i+t.length+1);if(d===61){const l=i+t.length+2,c=e.indexOf("&",l);return _e(e.slice(l,c===-1?void 0:c))}else if(d==38||isNaN(d))return"";i=e.indexOf(`&${t}`,i+1)}if(s=/[%+]/.test(e),!s)return}const r={};s??(s=/[%+]/.test(e));let n=e.indexOf("?",8);for(;n!==-1;){const i=e.indexOf("&",n+1);let d=e.indexOf("=",n);d>i&&i!==-1&&(d=-1);let l=e.slice(n+1,d===-1?i===-1?void 0:i:d);if(s&&(l=_e(l)),n=i,l==="")continue;let c;d===-1?c="":(c=e.slice(d+1,i===-1?void 0:i),s&&(c=_e(c))),a?(r[l]&&Array.isArray(r[l])||(r[l]=[]),r[l].push(c)):r[l]??(r[l]=c)}return t?r[t]:r},qt=ut,Gt=(e,t)=>ut(e,t,!0),ht=decodeURIComponent,We=e=>Ue(e,ht),le,D,B,pt,ft,Ke,q,at,gt=(at=class{constructor(e,t="/",a=[[]]){m(this,B);p(this,"raw");m(this,le);m(this,D);p(this,"routeIndex",0);p(this,"path");p(this,"bodyCache",{});m(this,q,e=>{const{bodyCache:t,raw:a}=this,s=t[e];if(s)return s;const r=Object.keys(t)[0];return r?t[r].then(n=>(r==="json"&&(n=JSON.stringify(n)),new Response(n)[e]())):t[e]=a[e]()});this.raw=e,this.path=t,g(this,D,a),g(this,le,{})}param(e){return e?x(this,B,pt).call(this,e):x(this,B,ft).call(this)}query(e){return qt(this.url,e)}queries(e){return Gt(this.url,e)}header(e){if(e)return this.raw.headers.get(e)??void 0;const t={};return this.raw.headers.forEach((a,s)=>{t[s]=a}),t}async parseBody(e){var t;return(t=this.bodyCache).parsedBody??(t.parsedBody=await Nt(this,e))}json(){return o(this,q).call(this,"text").then(e=>JSON.parse(e))}text(){return o(this,q).call(this,"text")}arrayBuffer(){return o(this,q).call(this,"arrayBuffer")}blob(){return o(this,q).call(this,"blob")}formData(){return o(this,q).call(this,"formData")}addValidatedData(e,t){o(this,le)[e]=t}valid(e){return o(this,le)[e]}get url(){return this.raw.url}get method(){return this.raw.method}get[Lt](){return o(this,D)}get matchedRoutes(){return o(this,D)[0].map(([[,e]])=>e)}get routePath(){return o(this,D)[0].map(([[,e]])=>e)[this.routeIndex].path}},le=new WeakMap,D=new WeakMap,B=new WeakSet,pt=function(e){const t=o(this,D)[0][this.routeIndex][1][e],a=x(this,B,Ke).call(this,t);return a&&/\%/.test(a)?We(a):a},ft=function(){const e={},t=Object.keys(o(this,D)[0][this.routeIndex][1]);for(const a of t){const s=x(this,B,Ke).call(this,o(this,D)[0][this.routeIndex][1][a]);s!==void 0&&(e[a]=/\%/.test(s)?We(s):s)}return e},Ke=function(e){return o(this,D)[1]?o(this,D)[1][e]:e},q=new WeakMap,at),$t={Stringify:1},mt=async(e,t,a,s,r)=>{typeof e=="object"&&!(e instanceof String)&&(e instanceof Promise||(e=e.toString()),e instanceof Promise&&(e=await e));const n=e.callbacks;return n!=null&&n.length?(r?r[0]+=e:r=[e],Promise.all(n.map(d=>d({phase:t,buffer:r,context:s}))).then(d=>Promise.all(d.filter(Boolean).map(l=>mt(l,t,!1,s,r))).then(()=>r[0]))):Promise.resolve(e)},zt="text/plain; charset=UTF-8",Be=(e,t)=>({"Content-Type":e,...t}),ve,ye,O,oe,F,E,we,ce,de,X,ke,Ae,G,ne,st,Jt=(st=class{constructor(e,t){m(this,G);m(this,ve);m(this,ye);p(this,"env",{});m(this,O);p(this,"finalized",!1);p(this,"error");m(this,oe);m(this,F);m(this,E);m(this,we);m(this,ce);m(this,de);m(this,X);m(this,ke);m(this,Ae);p(this,"render",(...e)=>(o(this,ce)??g(this,ce,t=>this.html(t)),o(this,ce).call(this,...e)));p(this,"setLayout",e=>g(this,we,e));p(this,"getLayout",()=>o(this,we));p(this,"setRenderer",e=>{g(this,ce,e)});p(this,"header",(e,t,a)=>{this.finalized&&g(this,E,new Response(o(this,E).body,o(this,E)));const s=o(this,E)?o(this,E).headers:o(this,X)??g(this,X,new Headers);t===void 0?s.delete(e):a!=null&&a.append?s.append(e,t):s.set(e,t)});p(this,"status",e=>{g(this,oe,e)});p(this,"set",(e,t)=>{o(this,O)??g(this,O,new Map),o(this,O).set(e,t)});p(this,"get",e=>o(this,O)?o(this,O).get(e):void 0);p(this,"newResponse",(...e)=>x(this,G,ne).call(this,...e));p(this,"body",(e,t,a)=>x(this,G,ne).call(this,e,t,a));p(this,"text",(e,t,a)=>!o(this,X)&&!o(this,oe)&&!t&&!a&&!this.finalized?new Response(e):x(this,G,ne).call(this,e,t,Be(zt,a)));p(this,"json",(e,t,a)=>x(this,G,ne).call(this,JSON.stringify(e),t,Be("application/json",a)));p(this,"html",(e,t,a)=>{const s=r=>x(this,G,ne).call(this,r,t,Be("text/html; charset=UTF-8",a));return typeof e=="object"?mt(e,$t.Stringify,!1,{}).then(s):s(e)});p(this,"redirect",(e,t)=>{const a=String(e);return this.header("Location",/[^\x00-\xFF]/.test(a)?encodeURI(a):a),this.newResponse(null,t??302)});p(this,"notFound",()=>(o(this,de)??g(this,de,()=>new Response),o(this,de).call(this,this)));g(this,ve,e),t&&(g(this,F,t.executionCtx),this.env=t.env,g(this,de,t.notFoundHandler),g(this,Ae,t.path),g(this,ke,t.matchResult))}get req(){return o(this,ye)??g(this,ye,new gt(o(this,ve),o(this,Ae),o(this,ke))),o(this,ye)}get event(){if(o(this,F)&&"respondWith"in o(this,F))return o(this,F);throw Error("This context has no FetchEvent")}get executionCtx(){if(o(this,F))return o(this,F);throw Error("This context has no ExecutionContext")}get res(){return o(this,E)||g(this,E,new Response(null,{headers:o(this,X)??g(this,X,new Headers)}))}set res(e){if(o(this,E)&&e){e=new Response(e.body,e);for(const[t,a]of o(this,E).headers.entries())if(t!=="content-type")if(t==="set-cookie"){const s=o(this,E).headers.getSetCookie();e.headers.delete("set-cookie");for(const r of s)e.headers.append("set-cookie",r)}else e.headers.set(t,a)}g(this,E,e),this.finalized=!0}get var(){return o(this,O)?Object.fromEntries(o(this,O)):{}}},ve=new WeakMap,ye=new WeakMap,O=new WeakMap,oe=new WeakMap,F=new WeakMap,E=new WeakMap,we=new WeakMap,ce=new WeakMap,de=new WeakMap,X=new WeakMap,ke=new WeakMap,Ae=new WeakMap,G=new WeakSet,ne=function(e,t,a){const s=o(this,E)?new Headers(o(this,E).headers):o(this,X)??new Headers;if(typeof t=="object"&&"headers"in t){const n=t.headers instanceof Headers?t.headers:new Headers(t.headers);for(const[i,d]of n)i.toLowerCase()==="set-cookie"?s.append(i,d):s.set(i,d)}if(a)for(const[n,i]of Object.entries(a))if(typeof i=="string")s.set(n,i);else{s.delete(n);for(const d of i)s.append(n,d)}const r=typeof t=="number"?t:(t==null?void 0:t.status)??o(this,oe);return new Response(e,{status:r,headers:s})},st),w="ALL",Wt="all",Vt=["get","post","put","delete","options","patch"],bt="Can not add a route since the matcher is already built.",xt=class extends Error{},Yt="__COMPOSED_HANDLER",Xt=e=>e.text("404 Not Found",404),Ve=(e,t)=>{if("getResponse"in e){const a=e.getResponse();return t.newResponse(a.body,a)}return console.error(e),t.text("Internal Server Error",500)},P,k,vt,L,V,De,Pe,ue,Qt=(ue=class{constructor(t={}){m(this,k);p(this,"get");p(this,"post");p(this,"put");p(this,"delete");p(this,"options");p(this,"patch");p(this,"all");p(this,"on");p(this,"use");p(this,"router");p(this,"getPath");p(this,"_basePath","/");m(this,P,"/");p(this,"routes",[]);m(this,L,Xt);p(this,"errorHandler",Ve);p(this,"onError",t=>(this.errorHandler=t,this));p(this,"notFound",t=>(g(this,L,t),this));p(this,"fetch",(t,...a)=>x(this,k,Pe).call(this,t,a[1],a[0],t.method));p(this,"request",(t,a,s,r)=>t instanceof Request?this.fetch(a?new Request(t,a):t,s,r):(t=t.toString(),this.fetch(new Request(/^https?:\/\//.test(t)?t:`http://localhost${re("/",t)}`,a),s,r)));p(this,"fire",()=>{addEventListener("fetch",t=>{t.respondWith(x(this,k,Pe).call(this,t.request,t,void 0,t.request.method))})});[...Vt,Wt].forEach(n=>{this[n]=(i,...d)=>(typeof i=="string"?g(this,P,i):x(this,k,V).call(this,n,o(this,P),i),d.forEach(l=>{x(this,k,V).call(this,n,o(this,P),l)}),this)}),this.on=(n,i,...d)=>{for(const l of[i].flat()){g(this,P,l);for(const c of[n].flat())d.map(u=>{x(this,k,V).call(this,c.toUpperCase(),o(this,P),u)})}return this},this.use=(n,...i)=>(typeof n=="string"?g(this,P,n):(g(this,P,"*"),i.unshift(n)),i.forEach(d=>{x(this,k,V).call(this,w,o(this,P),d)}),this);const{strict:s,...r}=t;Object.assign(this,r),this.getPath=s??!0?t.getPath??ct:Ut}route(t,a){const s=this.basePath(t);return a.routes.map(r=>{var i;let n;a.errorHandler===Ve?n=r.handler:(n=async(d,l)=>(await Je([],a.errorHandler)(d,()=>r.handler(d,l))).res,n[Yt]=r.handler),x(i=s,k,V).call(i,r.method,r.path,n)}),this}basePath(t){const a=x(this,k,vt).call(this);return a._basePath=re(this._basePath,t),a}mount(t,a,s){let r,n;s&&(typeof s=="function"?n=s:(n=s.optionHandler,s.replaceRequest===!1?r=l=>l:r=s.replaceRequest));const i=n?l=>{const c=n(l);return Array.isArray(c)?c:[c]}:l=>{let c;try{c=l.executionCtx}catch{}return[l.env,c]};r||(r=(()=>{const l=re(this._basePath,t),c=l==="/"?0:l.length;return u=>{const h=new URL(u.url);return h.pathname=h.pathname.slice(c)||"/",new Request(h,u)}})());const d=async(l,c)=>{const u=await a(r(l.req.raw),...i(l));if(u)return u;await c()};return x(this,k,V).call(this,w,re(t,"*"),d),this}},P=new WeakMap,k=new WeakSet,vt=function(){const t=new ue({router:this.router,getPath:this.getPath});return t.errorHandler=this.errorHandler,g(t,L,o(this,L)),t.routes=this.routes,t},L=new WeakMap,V=function(t,a,s){t=t.toUpperCase(),a=re(this._basePath,a);const r={basePath:this._basePath,path:a,method:t,handler:s};this.router.add(t,a,[s,r]),this.routes.push(r)},De=function(t,a){if(t instanceof Error)return this.errorHandler(t,a);throw t},Pe=function(t,a,s,r){if(r==="HEAD")return(async()=>new Response(null,await x(this,k,Pe).call(this,t,a,s,"GET")))();const n=this.getPath(t,{env:s}),i=this.router.match(r,n),d=new Jt(t,{path:n,matchResult:i,env:s,executionCtx:a,notFoundHandler:o(this,L)});if(i[0].length===1){let c;try{c=i[0][0][0][0](d,async()=>{d.res=await o(this,L).call(this,d)})}catch(u){return x(this,k,De).call(this,u,d)}return c instanceof Promise?c.then(u=>u||(d.finalized?d.res:o(this,L).call(this,d))).catch(u=>x(this,k,De).call(this,u,d)):c??o(this,L).call(this,d)}const l=Je(i[0],this.errorHandler,o(this,L));return(async()=>{try{const c=await l(d);if(!c.finalized)throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");return c.res}catch(c){return x(this,k,De).call(this,c,d)}})()},ue),yt=[];function Zt(e,t){const a=this.buildAllMatchers(),s=((r,n)=>{const i=a[r]||a[w],d=i[2][n];if(d)return d;const l=n.match(i[0]);if(!l)return[[],yt];const c=l.indexOf("",1);return[i[1][c],l]});return this.match=s,s(e,t)}var Ne="[^/]+",me=".*",be="(?:|/.*)",ie=Symbol(),ea=new Set(".\\+*[^]$()");function ta(e,t){return e.length===1?t.length===1?e<t?-1:1:-1:t.length===1||e===me||e===be?1:t===me||t===be?-1:e===Ne?1:t===Ne?-1:e.length===t.length?e<t?-1:1:t.length-e.length}var Q,Z,N,ae,aa=(ae=class{constructor(){m(this,Q);m(this,Z);m(this,N,Object.create(null))}insert(t,a,s,r,n){if(t.length===0){if(o(this,Q)!==void 0)throw ie;if(n)return;g(this,Q,a);return}const[i,...d]=t,l=i==="*"?d.length===0?["","",me]:["","",Ne]:i==="/*"?["","",be]:i.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);let c;if(l){const u=l[1];let h=l[2]||Ne;if(u&&l[2]&&(h===".*"||(h=h.replace(/^\((?!\?:)(?=[^)]+\)$)/,"(?:"),/\((?!\?:)/.test(h))))throw ie;if(c=o(this,N)[h],!c){if(Object.keys(o(this,N)).some(f=>f!==me&&f!==be))throw ie;if(n)return;c=o(this,N)[h]=new ae,u!==""&&g(c,Z,r.varIndex++)}!n&&u!==""&&s.push([u,o(c,Z)])}else if(c=o(this,N)[i],!c){if(Object.keys(o(this,N)).some(u=>u.length>1&&u!==me&&u!==be))throw ie;if(n)return;c=o(this,N)[i]=new ae}c.insert(d,a,s,r,n)}buildRegExpStr(){const a=Object.keys(o(this,N)).sort(ta).map(s=>{const r=o(this,N)[s];return(typeof o(r,Z)=="number"?`(${s})@${o(r,Z)}`:ea.has(s)?`\\${s}`:s)+r.buildRegExpStr()});return typeof o(this,Q)=="number"&&a.unshift(`#${o(this,Q)}`),a.length===0?"":a.length===1?a[0]:"(?:"+a.join("|")+")"}},Q=new WeakMap,Z=new WeakMap,N=new WeakMap,ae),Ce,je,rt,sa=(rt=class{constructor(){m(this,Ce,{varIndex:0});m(this,je,new aa)}insert(e,t,a){const s=[],r=[];for(let i=0;;){let d=!1;if(e=e.replace(/\{[^}]+\}/g,l=>{const c=`@\\${i}`;return r[i]=[c,l],i++,d=!0,c}),!d)break}const n=e.match(/(?::[^\/]+)|(?:\/\*$)|./g)||[];for(let i=r.length-1;i>=0;i--){const[d]=r[i];for(let l=n.length-1;l>=0;l--)if(n[l].indexOf(d)!==-1){n[l]=n[l].replace(d,r[i][1]);break}}return o(this,je).insert(n,t,s,o(this,Ce),a),s}buildRegExp(){let e=o(this,je).buildRegExpStr();if(e==="")return[/^$/,[],[]];let t=0;const a=[],s=[];return e=e.replace(/#(\d+)|@(\d+)|\.\*\$/g,(r,n,i)=>n!==void 0?(a[++t]=Number(n),"$()"):(i!==void 0&&(s[Number(i)]=++t),"")),[new RegExp(`^${e}`),a,s]}},Ce=new WeakMap,je=new WeakMap,rt),ra=[/^$/,[],Object.create(null)],Le=Object.create(null);function wt(e){return Le[e]??(Le[e]=new RegExp(e==="*"?"":`^${e.replace(/\/\*$|([.\\+*[^\]$()])/g,(t,a)=>a?`\\${a}`:"(?:|/.*)")}$`))}function na(){Le=Object.create(null)}function ia(e){var c;const t=new sa,a=[];if(e.length===0)return ra;const s=e.map(u=>[!/\*|\/:/.test(u[0]),...u]).sort(([u,h],[f,y])=>u?1:f?-1:h.length-y.length),r=Object.create(null);for(let u=0,h=-1,f=s.length;u<f;u++){const[y,A,R]=s[u];y?r[A]=[R.map(([j])=>[j,Object.create(null)]),yt]:h++;let v;try{v=t.insert(A,h,y)}catch(j){throw j===ie?new xt(A):j}y||(a[h]=R.map(([j,K])=>{const Te=Object.create(null);for(K-=1;K>=0;K--){const[Se,C]=v[K];Te[Se]=C}return[j,Te]}))}const[n,i,d]=t.buildRegExp();for(let u=0,h=a.length;u<h;u++)for(let f=0,y=a[u].length;f<y;f++){const A=(c=a[u][f])==null?void 0:c[1];if(!A)continue;const R=Object.keys(A);for(let v=0,j=R.length;v<j;v++)A[R[v]]=d[A[R[v]]]}const l=[];for(const u in i)l[u]=a[i[u]];return[n,l,r]}function se(e,t){if(e){for(const a of Object.keys(e).sort((s,r)=>r.length-s.length))if(wt(a).test(t))return[...e[a]]}}var $,z,Ie,kt,nt,la=(nt=class{constructor(){m(this,Ie);p(this,"name","RegExpRouter");m(this,$);m(this,z);p(this,"match",Zt);g(this,$,{[w]:Object.create(null)}),g(this,z,{[w]:Object.create(null)})}add(e,t,a){var d;const s=o(this,$),r=o(this,z);if(!s||!r)throw new Error(bt);s[e]||[s,r].forEach(l=>{l[e]=Object.create(null),Object.keys(l[w]).forEach(c=>{l[e][c]=[...l[w][c]]})}),t==="/*"&&(t="*");const n=(t.match(/\/:/g)||[]).length;if(/\*$/.test(t)){const l=wt(t);e===w?Object.keys(s).forEach(c=>{var u;(u=s[c])[t]||(u[t]=se(s[c],t)||se(s[w],t)||[])}):(d=s[e])[t]||(d[t]=se(s[e],t)||se(s[w],t)||[]),Object.keys(s).forEach(c=>{(e===w||e===c)&&Object.keys(s[c]).forEach(u=>{l.test(u)&&s[c][u].push([a,n])})}),Object.keys(r).forEach(c=>{(e===w||e===c)&&Object.keys(r[c]).forEach(u=>l.test(u)&&r[c][u].push([a,n]))});return}const i=dt(t)||[t];for(let l=0,c=i.length;l<c;l++){const u=i[l];Object.keys(r).forEach(h=>{var f;(e===w||e===h)&&((f=r[h])[u]||(f[u]=[...se(s[h],u)||se(s[w],u)||[]]),r[h][u].push([a,n-c+l+1]))})}}buildAllMatchers(){const e=Object.create(null);return Object.keys(o(this,z)).concat(Object.keys(o(this,$))).forEach(t=>{e[t]||(e[t]=x(this,Ie,kt).call(this,t))}),g(this,$,g(this,z,void 0)),na(),e}},$=new WeakMap,z=new WeakMap,Ie=new WeakSet,kt=function(e){const t=[];let a=e===w;return[o(this,$),o(this,z)].forEach(s=>{const r=s[e]?Object.keys(s[e]).map(n=>[n,s[e][n]]):[];r.length!==0?(a||(a=!0),t.push(...r)):e!==w&&t.push(...Object.keys(s[w]).map(n=>[n,s[w][n]]))}),a?ia(t):null},nt),J,H,it,oa=(it=class{constructor(e){p(this,"name","SmartRouter");m(this,J,[]);m(this,H,[]);g(this,J,e.routers)}add(e,t,a){if(!o(this,H))throw new Error(bt);o(this,H).push([e,t,a])}match(e,t){if(!o(this,H))throw new Error("Fatal error");const a=o(this,J),s=o(this,H),r=a.length;let n=0,i;for(;n<r;n++){const d=a[n];try{for(let l=0,c=s.length;l<c;l++)d.add(...s[l]);i=d.match(e,t)}catch(l){if(l instanceof xt)continue;throw l}this.match=d.match.bind(d),g(this,J,[d]),g(this,H,void 0);break}if(n===r)throw new Error("Fatal error");return this.name=`SmartRouter + ${this.activeRouter.name}`,i}get activeRouter(){if(o(this,H)||o(this,J).length!==1)throw new Error("No active router has been determined yet.");return o(this,J)[0]}},J=new WeakMap,H=new WeakMap,it),fe=Object.create(null),W,S,ee,he,T,_,Y,ge,ca=(ge=class{constructor(t,a,s){m(this,_);m(this,W);m(this,S);m(this,ee);m(this,he,0);m(this,T,fe);if(g(this,S,s||Object.create(null)),g(this,W,[]),t&&a){const r=Object.create(null);r[t]={handler:a,possibleKeys:[],score:0},g(this,W,[r])}g(this,ee,[])}insert(t,a,s){g(this,he,++ze(this,he)._);let r=this;const n=Ft(a),i=[];for(let d=0,l=n.length;d<l;d++){const c=n[d],u=n[d+1],h=Bt(c,u),f=Array.isArray(h)?h[0]:c;if(f in o(r,S)){r=o(r,S)[f],h&&i.push(h[1]);continue}o(r,S)[f]=new ge,h&&(o(r,ee).push(h),i.push(h[1])),r=o(r,S)[f]}return o(r,W).push({[t]:{handler:s,possibleKeys:i.filter((d,l,c)=>c.indexOf(d)===l),score:o(this,he)}}),r}search(t,a){var l;const s=[];g(this,T,fe);let n=[this];const i=ot(a),d=[];for(let c=0,u=i.length;c<u;c++){const h=i[c],f=c===u-1,y=[];for(let A=0,R=n.length;A<R;A++){const v=n[A],j=o(v,S)[h];j&&(g(j,T,o(v,T)),f?(o(j,S)["*"]&&s.push(...x(this,_,Y).call(this,o(j,S)["*"],t,o(v,T))),s.push(...x(this,_,Y).call(this,j,t,o(v,T)))):y.push(j));for(let K=0,Te=o(v,ee).length;K<Te;K++){const Se=o(v,ee)[K],C=o(v,T)===fe?{}:{...o(v,T)};if(Se==="*"){const U=o(v,S)["*"];U&&(s.push(...x(this,_,Y).call(this,U,t,o(v,T))),g(U,T,C),y.push(U));continue}const[Et,Ge,pe]=Se;if(!h&&!(pe instanceof RegExp))continue;const I=o(v,S)[Et],Mt=i.slice(c).join("/");if(pe instanceof RegExp){const U=pe.exec(Mt);if(U){if(C[Ge]=U[0],s.push(...x(this,_,Y).call(this,I,t,o(v,T),C)),Object.keys(o(I,S)).length){g(I,T,C);const Fe=((l=U[0].match(/\//))==null?void 0:l.length)??0;(d[Fe]||(d[Fe]=[])).push(I)}continue}}(pe===!0||pe.test(h))&&(C[Ge]=h,f?(s.push(...x(this,_,Y).call(this,I,t,C,o(v,T))),o(I,S)["*"]&&s.push(...x(this,_,Y).call(this,o(I,S)["*"],t,C,o(v,T)))):(g(I,T,C),y.push(I)))}}n=y.concat(d.shift()??[])}return s.length>1&&s.sort((c,u)=>c.score-u.score),[s.map(({handler:c,params:u})=>[c,u])]}},W=new WeakMap,S=new WeakMap,ee=new WeakMap,he=new WeakMap,T=new WeakMap,_=new WeakSet,Y=function(t,a,s,r){const n=[];for(let i=0,d=o(t,W).length;i<d;i++){const l=o(t,W)[i],c=l[a]||l[w],u={};if(c!==void 0&&(c.params=Object.create(null),n.push(c),s!==fe||r&&r!==fe))for(let h=0,f=c.possibleKeys.length;h<f;h++){const y=c.possibleKeys[h],A=u[c.score];c.params[y]=r!=null&&r[y]&&!A?r[y]:s[y]??(r==null?void 0:r[y]),u[c.score]=!0}}return n},ge),te,lt,da=(lt=class{constructor(){p(this,"name","TrieRouter");m(this,te);g(this,te,new ca)}add(e,t,a){const s=dt(t);if(s){for(let r=0,n=s.length;r<n;r++)o(this,te).insert(e,s[r],a);return}o(this,te).insert(e,t,a)}match(e,t){return o(this,te).search(e,t)}},te=new WeakMap,lt),At=class extends Qt{constructor(e={}){super(e),this.router=e.router??new oa({routers:[new la,new da]})}},ua=e=>{const a={...{origin:"*",allowMethods:["GET","HEAD","PUT","POST","DELETE","PATCH"],allowHeaders:[],exposeHeaders:[]},...e},s=(n=>typeof n=="string"?n==="*"?()=>n:i=>n===i?i:null:typeof n=="function"?n:i=>n.includes(i)?i:null)(a.origin),r=(n=>typeof n=="function"?n:Array.isArray(n)?()=>n:()=>[])(a.allowMethods);return async function(i,d){var u;function l(h,f){i.res.headers.set(h,f)}const c=await s(i.req.header("origin")||"",i);if(c&&l("Access-Control-Allow-Origin",c),a.credentials&&l("Access-Control-Allow-Credentials","true"),(u=a.exposeHeaders)!=null&&u.length&&l("Access-Control-Expose-Headers",a.exposeHeaders.join(",")),i.req.method==="OPTIONS"){a.origin!=="*"&&l("Vary","Origin"),a.maxAge!=null&&l("Access-Control-Max-Age",a.maxAge.toString());const h=await r(i.req.header("origin")||"",i);h.length&&l("Access-Control-Allow-Methods",h.join(","));let f=a.allowHeaders;if(!(f!=null&&f.length)){const y=i.req.header("Access-Control-Request-Headers");y&&(f=y.split(/\s*,\s*/))}return f!=null&&f.length&&(l("Access-Control-Allow-Headers",f.join(",")),i.res.headers.append("Vary","Access-Control-Request-Headers")),i.res.headers.delete("Content-Length"),i.res.headers.delete("Content-Type"),new Response(null,{headers:i.res.headers,status:204,statusText:"No Content"})}await d(),a.origin!=="*"&&i.header("Vary","Origin",{append:!0})}},ha=/^\s*(?:text\/(?!event-stream(?:[;\s]|$))[^;\s]+|application\/(?:javascript|json|xml|xml-dtd|ecmascript|dart|postscript|rtf|tar|toml|vnd\.dart|vnd\.ms-fontobject|vnd\.ms-opentype|wasm|x-httpd-php|x-javascript|x-ns-proxy-autoconfig|x-sh|x-tar|x-virtualbox-hdd|x-virtualbox-ova|x-virtualbox-ovf|x-virtualbox-vbox|x-virtualbox-vdi|x-virtualbox-vhd|x-virtualbox-vmdk|x-www-form-urlencoded)|font\/(?:otf|ttf)|image\/(?:bmp|vnd\.adobe\.photoshop|vnd\.microsoft\.icon|vnd\.ms-dds|x-icon|x-ms-bmp)|message\/rfc822|model\/gltf-binary|x-shader\/x-fragment|x-shader\/x-vertex|[^;\s]+?\+(?:json|text|xml|yaml))(?:[;\s]|$)/i,Ye=(e,t=pa)=>{const a=/\.([a-zA-Z0-9]+?)$/,s=e.match(a);if(!s)return;let r=t[s[1]];return r&&r.startsWith("text")&&(r+="; charset=utf-8"),r},ga={aac:"audio/aac",avi:"video/x-msvideo",avif:"image/avif",av1:"video/av1",bin:"application/octet-stream",bmp:"image/bmp",css:"text/css",csv:"text/csv",eot:"application/vnd.ms-fontobject",epub:"application/epub+zip",gif:"image/gif",gz:"application/gzip",htm:"text/html",html:"text/html",ico:"image/x-icon",ics:"text/calendar",jpeg:"image/jpeg",jpg:"image/jpeg",js:"text/javascript",json:"application/json",jsonld:"application/ld+json",map:"application/json",mid:"audio/x-midi",midi:"audio/x-midi",mjs:"text/javascript",mp3:"audio/mpeg",mp4:"video/mp4",mpeg:"video/mpeg",oga:"audio/ogg",ogv:"video/ogg",ogx:"application/ogg",opus:"audio/opus",otf:"font/otf",pdf:"application/pdf",png:"image/png",rtf:"application/rtf",svg:"image/svg+xml",tif:"image/tiff",tiff:"image/tiff",ts:"video/mp2t",ttf:"font/ttf",txt:"text/plain",wasm:"application/wasm",webm:"video/webm",weba:"audio/webm",webmanifest:"application/manifest+json",webp:"image/webp",woff:"font/woff",woff2:"font/woff2",xhtml:"application/xhtml+xml",xml:"application/xml",zip:"application/zip","3gp":"video/3gpp","3g2":"video/3gpp2",gltf:"model/gltf+json",glb:"model/gltf-binary"},pa=ga,fa=(...e)=>{let t=e.filter(r=>r!=="").join("/");t=t.replace(new RegExp("(?<=\\/)\\/+","g"),"");const a=t.split("/"),s=[];for(const r of a)r===".."&&s.length>0&&s.at(-1)!==".."?s.pop():r!=="."&&s.push(r);return s.join("/")||"."},jt={br:".br",zstd:".zst",gzip:".gz"},ma=Object.keys(jt),ba="index.html",xa=e=>{const t=e.root??"./",a=e.path,s=e.join??fa;return async(r,n)=>{var u,h,f,y;if(r.finalized)return n();let i;if(e.path)i=e.path;else try{if(i=decodeURIComponent(r.req.path),/(?:^|[\/\\])\.\.(?:$|[\/\\])/.test(i))throw new Error}catch{return await((u=e.onNotFound)==null?void 0:u.call(e,r.req.path,r)),n()}let d=s(t,!a&&e.rewriteRequestPath?e.rewriteRequestPath(i):i);e.isDir&&await e.isDir(d)&&(d=s(d,ba));const l=e.getContent;let c=await l(d,r);if(c instanceof Response)return r.newResponse(c.body,c);if(c){const A=e.mimes&&Ye(d,e.mimes)||Ye(d);if(r.header("Content-Type",A||"application/octet-stream"),e.precompressed&&(!A||ha.test(A))){const R=new Set((h=r.req.header("Accept-Encoding"))==null?void 0:h.split(",").map(v=>v.trim()));for(const v of ma){if(!R.has(v))continue;const j=await l(d+jt[v],r);if(j){c=j,r.header("Content-Encoding",v),r.header("Vary","Accept-Encoding",{append:!0});break}}}return await((f=e.onFound)==null?void 0:f.call(e,d,r)),r.body(c)}await((y=e.onNotFound)==null?void 0:y.call(e,d,r)),await n()}},va=async(e,t)=>{let a;t&&t.manifest?typeof t.manifest=="string"?a=JSON.parse(t.manifest):a=t.manifest:typeof __STATIC_CONTENT_MANIFEST=="string"?a=JSON.parse(__STATIC_CONTENT_MANIFEST):a=__STATIC_CONTENT_MANIFEST;let s;t&&t.namespace?s=t.namespace:s=__STATIC_CONTENT;const r=a[e]||e;if(!r)return null;const n=await s.get(r,{type:"stream"});return n||null},ya=e=>async function(a,s){return xa({...e,getContent:async n=>va(n,{manifest:e.manifest,namespace:e.namespace?e.namespace:a.env?a.env.__STATIC_CONTENT:void 0})})(a,s)},wa=e=>ya(e);async function ka(e,t){try{const s=(await e.prepare(`
      INSERT INTO transactions (nomor_ba, tanggal, jenis_transaksi, lokasi_asal, lokasi_tujuan, pemeriksa, penerima, ttd_pemeriksa, ttd_penerima)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(t.nomorBA,t.tanggal,t.jenisTransaksi,t.lokasiAsal,t.lokasiTujuan,t.pemeriksa,t.penerima,t.ttdPemeriksa,t.ttdPenerima).run()).meta.last_row_id;for(const r of t.materials){let n=r.jenisBarang;if(!n||n==="-"||n.trim()===""){const i=await e.prepare(`
          SELECT JENIS_BARANG FROM master_material 
          WHERE PART_NUMBER = ? LIMIT 1
        `).bind(r.partNumber).first();n=(i==null?void 0:i.JENIS_BARANG)||"MATERIAL HANDAL",console.log(`🔄 Auto-filled jenisBarang for ${r.partNumber}: ${n}`)}await e.prepare(`
        INSERT INTO materials (transaction_id, part_number, jenis_barang, material, mesin, sn_mesin, jumlah)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).bind(s,r.partNumber,n,r.material,r.mesin,r.snMesin,r.jumlah).run()}return{success:!0,id:s,nomorBA:t.nomorBA}}catch(a){throw console.error("Failed to save transaction:",a),new Error(`Database error: ${a.message}`)}}async function Oe(e){try{const{results:t}=await e.prepare(`
      SELECT 
        t.*,
        json_group_array(
          json_object(
            'partNumber', m.part_number,
            'jenisBarang', m.jenis_barang,
            'material', m.material,
            'mesin', m.mesin,
            'snMesin', m.sn_mesin,
            'jumlah', m.jumlah
          )
        ) as materials
      FROM transactions t
      LEFT JOIN materials m ON t.id = m.transaction_id
      GROUP BY t.id
      ORDER BY t.created_at DESC
    `).all();return t.map(a=>({...a,materials:JSON.parse(a.materials)}))}catch(t){return console.error("Failed to get transactions:",t),[]}}async function Aa(e){try{const{results:t}=await e.prepare(`
      SELECT nomor_ba FROM transactions ORDER BY created_at DESC LIMIT 1
    `).all();if(t.length===0)return"BA-2025-0001";const a=t[0];return`BA-2025-${(parseInt(a.nomor_ba.split("-")[2])+1).toString().padStart(4,"0")}`}catch{return"BA-2025-0001"}}const b=new At;b.use("/api/*",ua());b.use("/static/*",wa({root:"./public"}));const ja="https://script.googleusercontent.com/macros/echo?user_content_key=AehSKLibGBLpxhVKoCyNyEKKy3qLChkzbGk3u0B2OCnrRjQaVhgK7zrqCow5s2sWgqaCh97_c6L4jYn8GL1rz-GAlp_GuD3cWN8epmzIRv225YwSNEC6y3wp4ENvOpNITmxK2ic37e8c-UQSH2cbaBLT9mixv92O8sCA-ptW_LnjtZlzNrBzEjWXEKdNgCbOa_ZYVRIAnEzBLqeFCW7XQocgooPzv4xiOKaTXfR81vrwdC_xm4-pJVoMdgmyuldvxNMvM-vokUUcMdTkA-SG6wMRDg2UgAHC34GkfrC6ebYs&lib=MRb65GHGTxo8fAtO2JZr8dy1qv6vbq6ko";let Tt=[],M=[],Xe=!1;function Ta(){if(Xe||M.length>0){console.log("⚠️ Sample data already initialized, skipping...");return}console.log("🔧 Initializing sample gangguan data..."),M.push({id:"sample_"+Date.now(),nomorLH05:"SAMPLE001/ND KAL 2/LH05/2025",hariTanggal:new Date().toISOString().slice(0,16),unitULD:"TELAGA",kelompokSPD:"MEKANIK",komponenRusak:"Cylinder Liner",gejala:"Kebocoran pada cylinder liner unit TELAGA",uraianKejadian:"Ditemukan kebocoran oli pada cylinder liner bagian atas",analisaPenyebab:"Seal cylinder liner sudah aus dan perlu diganti",kesimpulan:"Perlu penggantian cylinder liner segera",bebanPuncak:300,dayaMampu:250,pemadaman:"NORMAL",tindakanPenanggulangan:"Isolasi unit sementara dan monitoring ketat",rencanaPerbaikan:"Ganti cylinder liner dalam 24 jam",materials:[{partNumber:"0490 1316",jenisBarang:"SPARE PART UTAMA",material:"CYLINDER LINER",mesin:"TCD 2013",jumlah:1,status:"Pengadaan"}],namaPelapor:"System Admin (Sample Data)",ttdPelapor:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",createdAt:new Date().toISOString()}),Xe=!0,console.log("✅ Sample gangguan data initialized:",M.length,"items")}Ta();let Qe=M.length+1,Re=new Map,Sa=new Map;const Ze={username:"AMC@12345",password:"12345@AMC"};let xe=new Map,Me=[],et=0;const Ea=300*1e3;async function qe(){const e=Date.now();if(Me.length>0&&e-et<Ea)return Me;try{const t=await fetch(ja,{headers:{"User-Agent":"Mozilla/5.0"},redirect:"follow"});if(!t.ok)throw new Error(`HTTP error! status: ${t.status}`);const a=await t.json();return Me=a,et=e,a}catch(t){return console.error("Error fetching Google Sheets data:",t),Me}}function Ma(){const e=String(Qe).padStart(3,"0"),t=new Date().getFullYear();return Qe++,`${e}/ND KAL 2/LH05/${t}`}b.get("/api/data",async e=>{try{const t=await qe();return e.json(t)}catch{return e.json({error:"Failed to fetch data"},500)}});b.get("/api/search-part",async e=>{var a;const t=((a=e.req.query("q"))==null?void 0:a.toLowerCase())||"";if(!t)return e.json({results:[]});try{const r=(await qe()).filter(n=>String(n.PART_NUMBER||"").toLowerCase().includes(t));return e.json({results:r.slice(0,10)})}catch{return e.json({error:"Search failed"},500)}});b.get("/api/dropdown-values",async e=>{try{const t=await qe(),a=[...new Set(t.map(n=>n.UNIT).filter(Boolean))].sort(),s=[...new Set(t.map(n=>n.Pemeriksa).filter(Boolean))].sort(),r=[...new Set(t.map(n=>n.Penerima).filter(Boolean))].sort();return e.json({units:a,pemeriksa:s,penerima:r})}catch{return e.json({error:"Failed to get dropdown values"},500)}});b.post("/api/save-transaction",async e=>{try{const{env:t}=e,a=await e.req.json(),s=await Aa(t.DB),r=await ka(t.DB,{nomorBA:s,...a}),n={id:Date.now().toString(),nomorBA:s,...a,createdAt:new Date().toISOString()};return Tt.push(n),e.json({success:!0,message:"Transaction saved successfully (D1 Database)",nomorBA:s,data:n})}catch(t){return console.error("Failed to save transaction:",t),e.json({error:t.message||"Failed to save transaction"},500)}});b.get("/api/transactions",async e=>{try{const{env:t}=e;if(!t.DB)return console.error("❌ D1 Database binding (DB) not found!"),e.json({error:"Database not configured",transactions:[],help:"Check wrangler.jsonc d1_databases binding"},500);console.log("🔄 Fetching transactions from D1...");const a=await Oe(t.DB);return console.log(`✅ Fetched ${a.length} transactions from D1`),e.json({transactions:a,source:"D1 Database",count:a.length})}catch(t){return console.error("❌ Failed to get transactions:",t.message,t.stack),e.json({error:`Database query failed: ${t.message}`,transactions:[],details:"Check Cloudflare Pages logs for full error trace"},500)}});b.get("/api/dashboard/stock",async e=>{try{const{env:t}=e,a=e.req.query("jenis")||"",s=e.req.query("mesin")||"",r=await Oe(t.DB),n={};r.forEach(d=>{d.materials.forEach(l=>{const c=l.partNumber;n[c]||(n[c]={partNumber:l.partNumber,jenisBarang:l.jenisBarang,material:l.material,mesin:l.mesin,stokMasuk:0,stokKeluar:0,stokAkhir:0,unit:d.lokasi_tujuan}),d.jenis_transaksi.includes("Masuk")?n[c].stokMasuk+=l.jumlah:n[c].stokKeluar+=l.jumlah,n[c].stokAkhir=n[c].stokMasuk-n[c].stokKeluar})});let i=Object.values(n);return a&&(i=i.filter(d=>d.jenisBarang===a)),s&&(i=i.filter(d=>d.mesin===s)),i=i.map(d=>({...d,status:d.stokAkhir===0?"Habis":d.stokAkhir<=10?"Hampir Habis":"Tersedia"})),e.json({stock:i})}catch(t){return console.error("Failed to get stock:",t),e.json({stock:[]},500)}});b.get("/api/dashboard/umur-material",async e=>{try{const{env:t}=e,a=e.req.query("lokasi")||"",s=e.req.query("material")||"",r=await Oe(t.DB),n={},i=new Date;i.setHours(0,0,0,0),r.filter(l=>l.jenis_transaksi.includes("Keluar")).sort((l,c)=>new Date(l.tanggal).getTime()-new Date(c.tanggal).getTime()).forEach(l=>{l.materials.forEach(c=>{if(!c.snMesin)return;const u=`${c.snMesin}_${c.partNumber}`,h=new Date(l.tanggal);h.setHours(0,0,0,0);const f=i.getTime()-h.getTime(),y=Math.floor(f/(1e3*60*60*24));n[u]={partNumber:c.partNumber,material:c.material,mesin:c.mesin,snMesin:c.snMesin,lokasi:l.lokasi_tujuan,tanggalPasang:l.tanggal,umurHari:y,nomorBA:l.nomor_ba,pemeriksa:l.pemeriksa,penerima:l.penerima}})});let d=Object.values(n);return a&&(d=d.filter(l=>l.lokasi===a)),s&&(d=d.filter(l=>l.material.includes(s))),e.json({ageData:d})}catch(t){return console.error("Failed to get material age:",t),e.json({ageData:[]},500)}});b.get("/api/ba/:nomor",async e=>{try{const{env:t}=e,a=e.req.param("nomor"),r=(await Oe(t.DB)).find(n=>n.nomor_ba===a);if(!r){const n=Tt.find(i=>i.nomorBA===a);return n?e.json({ba:n}):e.json({error:"BA not found"},404)}return e.json({ba:r})}catch(t){return console.error("Failed to get BA:",t),e.json({error:"Failed to get BA"},500)}});b.get("/api/material-history/:snMesin/:partNumber",e=>{const t=e.req.param("snMesin"),a=e.req.param("partNumber"),s=`${t}_${a}`,r=Sa.get(s)||[];return e.json({snMesin:t,partNumber:a,totalPenggantian:r.length,history:r})});b.get("/api/target-umur",e=>{const t=Array.from(Re.values());return e.json({targets:t})});b.post("/api/target-umur",async e=>{try{const t=await e.req.json(),{partNumber:a,targetUmurHari:s,jenisBarang:r,material:n,mesin:i}=t;return!a||!s?e.json({error:"Part number and target umur required"},400):(Re.set(a,{partNumber:a,targetUmurHari:parseInt(s),jenisBarang:r,material:n,mesin:i,updatedAt:new Date().toISOString()}),e.json({success:!0,message:"Target umur saved successfully",data:Re.get(a)}))}catch{return e.json({error:"Failed to save target umur"},500)}});b.get("/api/target-umur/:partNumber",e=>{const t=e.req.param("partNumber"),a=Re.get(t);return a?e.json({...a,isDefault:!1}):e.json({partNumber:t,targetUmurHari:365,isDefault:!0})});b.post("/api/login",async e=>{try{const{username:t,password:a}=await e.req.json();if(t===Ze.username&&a===Ze.password){const s=`session_${Date.now()}_${Math.random().toString(36).substring(7)}`;return xe.set(s,{username:t,loginTime:new Date().toISOString(),expiresAt:new Date(Date.now()+480*60*1e3).toISOString()}),e.json({success:!0,message:"Login successful",sessionToken:s})}else return e.json({success:!1,message:"Username atau password salah"},401)}catch{return e.json({error:"Login failed"},500)}});b.post("/api/logout",async e=>{try{const t=e.req.header("Authorization"),a=t==null?void 0:t.replace("Bearer ","");return a&&xe.delete(a),e.json({success:!0,message:"Logout successful"})}catch{return e.json({error:"Logout failed"},500)}});b.get("/api/check-session",e=>{const t=e.req.header("Authorization"),a=t==null?void 0:t.replace("Bearer ","");if(!a||!xe.has(a))return e.json({valid:!1},401);const s=xe.get(a),r=new Date,n=new Date(s.expiresAt);return r>n?(xe.delete(a),e.json({valid:!1,message:"Session expired"},401)):e.json({valid:!0,username:s.username,expiresAt:s.expiresAt})});b.post("/api/save-gangguan",async e=>{try{const t=await e.req.json();console.log("💾 Saving gangguan form..."),console.log("📋 Form data received:",JSON.stringify(t).substring(0,200)+"...");const a=Ma();console.log("🏷️ Generated Nomor LH05:",a);const s={id:Date.now().toString(),nomorLH05:a,...t,createdAt:new Date().toISOString()};return M.push(s),console.log("✅ Gangguan saved successfully"),console.log("📊 Total gangguan now:",M.length),console.log("🗂️ Last 3 items:",M.slice(-3).map(r=>r.nomorLH05)),e.json({success:!0,message:"Form gangguan saved successfully",nomorLH05:a,data:s})}catch(t){return console.error("❌ Error saving gangguan:",t),e.json({error:"Failed to save gangguan"},500)}});b.get("/api/gangguan-transactions",e=>(console.log("🔍 GET /api/gangguan-transactions called"),console.log("📊 Total gangguan:",M.length),console.log("🗂️ Gangguan list:",M.map(t=>{var a;return{nomor:t.nomorLH05,unit:t.unitULD,kelompok:t.kelompokSPD,materials:((a=t.materials)==null?void 0:a.length)||0}})),e.json({gangguanTransactions:M})));b.get("/api/gangguan/:nomor",e=>{const t=e.req.param("nomor"),a=M.find(s=>s.nomorLH05===t);return a?e.json({gangguan:a}):e.json({error:"LH05 not found"},404)});b.get("/api/dashboard/gangguan",e=>{const t=e.req.query("kelompok")||"",a=e.req.query("tanggal")||"";let s=M;return t&&(s=s.filter(r=>r.kelompokSPD===t)),a&&(s=s.filter(r=>{var n;return(n=r.hariTanggal)==null?void 0:n.includes(a)})),e.json({data:s})});b.get("/api/kebutuhan-material",e=>{const t=e.req.query("status")||"",a=e.req.query("nomor")||"";let s=[];return M.forEach(r=>{r.materials&&Array.isArray(r.materials)&&r.materials.forEach(n=>{s.push({...n,nomorLH05:r.nomorLH05,unitULD:r.unitULD,lokasiTujuan:r.unitULD,tanggalGangguan:r.hariTanggal,kelompokSPD:r.kelompokSPD,status:n.status||"Pengadaan"})})}),t&&(s=s.filter(r=>r.status===t)),a&&(s=s.filter(r=>r.nomorLH05.includes(a))),e.json({materials:s})});b.post("/api/update-material-status",async e=>{var t;try{const{nomorLH05:a,partNumber:s,status:r}=await e.req.json(),n=M.find(d=>d.nomorLH05===a);if(!n)return e.json({error:"Gangguan not found"},404);const i=(t=n.materials)==null?void 0:t.find(d=>d.partNumber===s);return i?(i.status=r,i.updatedAt=new Date().toISOString(),e.json({success:!0,message:"Status updated",material:i})):e.json({error:"Material not found"},404)}catch{return e.json({error:"Failed to update status"},500)}});b.get("/",e=>e.html(Da()));b.get("/dashboard/stok",e=>e.html(Pa()));b.get("/dashboard/umur",e=>e.html(La()));b.get("/dashboard/mutasi",e=>e.html(Na()));b.get("/login",e=>e.html(Ca()));b.get("/form-gangguan",e=>e.html(Ra()));b.get("/dashboard/gangguan",e=>e.html(Oa()));b.get("/dashboard/kebutuhan-material",e=>e.html(Ia()));function Da(){return`
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sistem Inventaris Spare Part</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <style>
          .signature-pad {
            border: 2px dashed #cbd5e1;
            border-radius: 8px;
            cursor: crosshair;
          }
          .signature-pad:hover {
            border-color: #3b82f6;
          }
        </style>
    </head>
    <body class="bg-gray-50">
        <!-- Navigation -->
        <nav class="bg-blue-600 text-white p-4 shadow-lg">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-warehouse text-2xl"></i>
                    <span class="text-xl font-bold">Sistem Manajemen Material</span>
                </div>
                <div class="flex flex-wrap space-x-2 items-center">
                    <a href="/" class="px-3 py-2 bg-blue-700 rounded hover:bg-blue-800">
                        <i class="fas fa-plus mr-1"></i>Input Material
                    </a>
                    <a href="/form-gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exclamation-triangle mr-1"></i>Form Gangguan
                    </a>
                    <a href="/dashboard/stok" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-chart-bar mr-1"></i>Stok
                    </a>
                    <a href="/dashboard/umur" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-calendar-alt mr-1"></i>Umur
                    </a>
                    <a href="/dashboard/mutasi" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exchange-alt mr-1"></i>Mutasi
                    </a>
                    <a href="/dashboard/gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-tools mr-1"></i>Gangguan
                    </a>
                    <button onclick="logout()" class="px-3 py-2 bg-red-600 hover:bg-blue-700 rounded ml-4">
                        <i class="fas fa-sign-out-alt mr-1"></i>Logout
                    </button>
                </div>
            </div>
        </nav>

        <div class="min-h-screen py-8 px-4">
            <div class="max-w-5xl mx-auto">
                <!-- Header -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <h1 class="text-3xl font-bold text-gray-800 mb-2">
                        <i class="fas fa-clipboard-list text-blue-600 mr-3"></i>
                        Form Input Transaksi Material
                    </h1>
                    <p class="text-gray-600">Pengeluaran dan Penerimaan Gudang</p>
                </div>

                <!-- Form -->
                <form id="transactionForm" class="space-y-6">
                    <!-- Informasi Umum -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                            <i class="fas fa-info-circle text-blue-600 mr-2"></i>
                            INFORMASI UMUM
                        </h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Tanggal</label>
                                <input type="date" id="tanggal" required
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Jenis Transaksi</label>
                                <select id="jenisTransaksi" required
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                                    <option value="">-- Pilih Jenis --</option>
                                    <option value="Keluar (Pengeluaran Gudang)">Keluar (Pengeluaran Gudang)</option>
                                    <option value="Masuk (Penerimaan Gudang)">Masuk (Penerimaan Gudang)</option>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Lokasi Keluar/Asal</label>
                                <select id="lokasiAsal" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                                    <option value="">-- Pilih Lokasi --</option>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Lokasi Tujuan</label>
                                <select id="lokasiTujuan" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                                    <option value="">-- Pilih Lokasi --</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- Detail Material -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            <i class="fas fa-boxes text-blue-600 mr-2"></i>
                            Detail Material
                        </h2>
                        
                        <div id="materialList" class="space-y-4"></div>
                        
                        <button type="button" id="addMaterial" 
                            class="w-full mt-4 bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition flex items-center justify-center">
                            <i class="fas fa-plus mr-2"></i>
                            Tambah Baris Material
                        </button>
                    </div>

                    <!-- Penanggung Jawab -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            <i class="fas fa-user-check text-blue-600 mr-2"></i>
                            Penanggung Jawab dan Validasi
                        </h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Pemeriksa</label>
                                <select id="pemeriksa" required class="w-full px-4 py-2 border border-gray-300 rounded-lg mb-4">
                                    <option value="">-- Pilih Pemeriksa --</option>
                                </select>
                                
                                <label class="block text-sm font-medium text-gray-700 mb-2">Tanda Tangan Pemeriksa</label>
                                <canvas id="signaturePemeriksa" width="300" height="150" class="signature-pad w-full bg-gray-50"></canvas>
                                <button type="button" id="clearPemeriksa" class="mt-2 text-sm text-red-600 hover:text-red-700">
                                    <i class="fas fa-eraser mr-1"></i>Hapus
                                </button>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Penerima</label>
                                <select id="penerima" required class="w-full px-4 py-2 border border-gray-300 rounded-lg mb-4">
                                    <option value="">-- Pilih Penerima --</option>
                                </select>
                                
                                <label class="block text-sm font-medium text-gray-700 mb-2">Tanda Tangan Penerima</label>
                                <canvas id="signaturePenerima" width="300" height="150" class="signature-pad w-full bg-gray-50"></canvas>
                                <button type="button" id="clearPenerima" class="mt-2 text-sm text-red-600 hover:text-red-700">
                                    <i class="fas fa-eraser mr-1"></i>Hapus
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Submit -->
                    <div class="flex gap-4">
                        <button type="submit" 
                            class="flex-1 bg-green-600 text-white py-4 px-6 rounded-lg hover:bg-blue-700 transition text-lg font-semibold">
                            <i class="fas fa-save mr-2"></i>Simpan Transaksi
                        </button>
                        <button type="button" id="resetForm"
                            class="px-6 py-4 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition">
                            <i class="fas fa-undo mr-2"></i>Reset
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <script src="/static/auth-check.js"><\/script>
        <script src="/static/app.js"><\/script>
    </body>
    </html>
  `}function Pa(){return`
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard Stok Material</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <nav class="bg-blue-600 text-white p-4 shadow-lg">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-chart-bar text-2xl"></i>
                    <span class="text-xl font-bold">Dashboard Stok Material</span>
                </div>
                <div class="flex flex-wrap space-x-2 items-center">
                    <a href="/" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-plus mr-1"></i>Input Material
                    </a>
                    <a href="/form-gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exclamation-triangle mr-1"></i>Form Gangguan
                    </a>
                    <a href="/dashboard/stok" class="px-3 py-2 bg-blue-700 rounded hover:bg-blue-800">
                        <i class="fas fa-chart-bar mr-1"></i>Stok
                    </a>
                    <a href="/dashboard/umur" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-calendar-alt mr-1"></i>Umur
                    </a>
                    <a href="/dashboard/mutasi" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exchange-alt mr-1"></i>Mutasi
                    </a>
                    <a href="/dashboard/gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-tools mr-1"></i>Gangguan
                    </a>
                    <a href="/dashboard/kebutuhan-material" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-clipboard-list mr-1"></i>Kebutuhan
                    </a>
                    <button onclick="logout()" class="px-3 py-2 bg-red-600 hover:bg-blue-700 rounded ml-4">
                        <i class="fas fa-sign-out-alt mr-1"></i>Logout
                    </button>
                </div>
            </div>
        </nav>

        <div class="flex">
            <!-- Sidebar Filter (Kiri) -->
            <div class="w-64 bg-white shadow-lg p-6 min-h-screen">
                <h2 class="text-xl font-bold mb-6 text-gray-800">
                    <i class="fas fa-filter mr-2 text-green-600"></i>
                    Filter Data
                </h2>
                
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium mb-2">Jenis Barang</label>
                        <div class="space-y-2">
                            <button onclick="filterJenis('MATERIAL HANDAL')" 
                                class="w-full text-left px-3 py-2 bg-blue-100 hover:bg-blue-200 rounded text-sm">
                                MATERIAL HANDAL
                            </button>
                            <button onclick="filterJenis('FILTER')" 
                                class="w-full text-left px-3 py-2 bg-green-100 hover:bg-green-200 rounded text-sm">
                                FILTER
                            </button>
                            <button onclick="filterJenis('MATERIAL BEKAS')" 
                                class="w-full text-left px-3 py-2 bg-yellow-100 hover:bg-yellow-200 rounded text-sm">
                                MATERIAL BEKAS
                            </button>
                            <button onclick="filterJenis('')" 
                                class="w-full text-left px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded text-sm">
                                SEMUA
                            </button>
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2">Cari Part Number</label>
                        <input type="text" id="searchPart" placeholder="Cari..." 
                            class="w-full px-3 py-2 border rounded-lg text-sm">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2">Filter Mesin</label>
                        <select id="filterMesin" class="w-full px-3 py-2 border rounded-lg text-sm">
                            <option value="">Semua</option>
                        </select>
                    </div>
                    
                    <div class="pt-4 border-t">
                        <button onclick="exportPDF()" class="w-full bg-green-600 text-white py-2 rounded hover:bg-blue-700 mb-2 text-sm">
                            <i class="fas fa-file-pdf mr-2"></i>PDF
                        </button>
                        <button onclick="exportExcel()" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 text-sm">
                            <i class="fas fa-file-excel mr-2"></i>Excel
                        </button>
                    </div>
                </div>
                
                <div class="mt-8 p-4 bg-green-50 rounded-lg">
                    <h3 class="font-semibold text-green-800 mb-2">
                        <i class="fas fa-info-circle mr-2"></i>
                        Status Stok
                    </h3>
                    <div class="space-y-2 text-sm">
                        <div class="flex items-center">
                            <span class="w-3 h-3 bg-red-500 rounded-full mr-2"></span>
                            <span>Habis (0)</span>
                        </div>
                        <div class="flex items-center">
                            <span class="w-3 h-3 bg-yellow-500 rounded-full mr-2"></span>
                            <span>Hampir Habis (≤10)</span>
                        </div>
                        <div class="flex items-center">
                            <span class="w-3 h-3 bg-green-500 rounded-full mr-2"></span>
                            <span>Tersedia (>10)</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Content (Kanan) -->
            <div class="flex-1 p-6">
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <h2 class="text-2xl font-bold text-gray-800">
                        <i class="fas fa-boxes mr-2 text-green-600"></i>
                        Daftar Stok Material
                    </h2>
                </div>

                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <table class="w-full">
                        <thead class="bg-blue-500 text-white">
                            <tr>
                                <th class="px-4 py-3 text-left">Part Number</th>
                                <th class="px-4 py-3 text-left">Jenis Barang</th>
                                <th class="px-4 py-3 text-left">Material</th>
                                <th class="px-4 py-3 text-left">Mesin</th>
                                <th class="px-4 py-3 text-center">Stok Masuk</th>
                                <th class="px-4 py-3 text-center">Stok Keluar</th>
                                <th class="px-4 py-3 text-center">Stok Akhir</th>
                                <th class="px-4 py-3 text-left">Unit</th>
                            </tr>
                        </thead>
                        <tbody id="stockTable">
                            <tr>
                                <td colspan="8" class="px-4 py-8 text-center text-gray-500">
                                    Belum ada data transaksi
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <script src="/static/auth-check.js"><\/script>
        <script src="/static/dashboard-stok.js"><\/script>
    </body>
    </html>
  `}function La(){return`
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard Umur Material</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <!-- Navigation -->
        <nav class="bg-blue-600 text-white p-4 shadow-lg">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-calendar-alt text-2xl"></i>
                    <span class="text-xl font-bold">Dashboard Umur Material</span>
                </div>
                <div class="flex flex-wrap space-x-2">
                    <a href="/" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-plus mr-1"></i>Input Material
                    </a>
                    <a href="/form-gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exclamation-triangle mr-1"></i>Form Gangguan
                    </a>
                    <a href="/dashboard/stok" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-chart-bar mr-1"></i>Stok
                    </a>
                    <a href="/dashboard/umur" class="px-3 py-2 bg-blue-700 rounded hover:bg-blue-800">
                        <i class="fas fa-calendar-alt mr-1"></i>Umur
                    </a>
                    <a href="/dashboard/mutasi" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exchange-alt mr-1"></i>Mutasi
                    </a>
                    <a href="/dashboard/gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-tools mr-1"></i>Gangguan
                    </a>
                    <a href="/dashboard/kebutuhan-material" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-clipboard-list mr-1"></i>Kebutuhan
                    </a>
                    <button onclick="logout()" class="px-3 py-2 bg-red-600 hover:bg-blue-700 rounded ml-4">
                        <i class="fas fa-sign-out-alt mr-1"></i>Logout
                    </button>
                </div>
            </div>
        </nav>

        <!-- Main Content with Sidebar -->
        <div class="flex">
            <!-- Sidebar Filter (Vertical) -->
            <aside class="w-80 bg-gray-900 shadow-lg min-h-screen p-6">
                <h2 class="text-2xl font-bold text-blue-400 mb-6 flex items-center">
                    <i class="fas fa-filter mr-2"></i>
                    Filter Material
                </h2>
                
                <div class="space-y-6">
                    <!-- Filter Lokasi -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-300 mb-3">
                            <i class="fas fa-map-marker-alt mr-2 text-pink-600"></i>
                            Lokasi
                        </label>
                        <select id="filterLokasi" class="w-full px-4 py-2 bg-gray-800 text-white border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500">
                            <option value="">Semua Lokasi</option>
                        </select>
                    </div>
                    
                    <!-- Filter Material -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-300 mb-3">
                            <i class="fas fa-box mr-2 text-pink-600"></i>
                            Material
                        </label>
                        <input type="text" id="filterMaterial" placeholder="Cari Material..." 
                            class="w-full px-4 py-2 bg-gray-800 text-white border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500">
                    </div>
                    
                    <!-- Filter S/N Mesin -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-300 mb-3">
                            <i class="fas fa-barcode mr-2 text-pink-600"></i>
                            S/N Mesin
                        </label>
                        <input type="text" id="filterSN" placeholder="Cari S/N Mesin..." 
                            class="w-full px-4 py-2 bg-gray-800 text-white border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500">
                    </div>

                    <!-- Status Legend -->
                    <div class="mt-8 p-4 bg-white rounded-lg shadow-md">
                        <h3 class="font-semibold text-pink-800 mb-3">
                            <i class="fas fa-info-circle mr-2"></i>
                            Keterangan Status
                        </h3>
                        <div class="space-y-2 text-sm text-gray-700">
                            <div class="flex items-center">
                                <span class="inline-block w-4 h-4 bg-red-100 border-2 border-red-500 rounded mr-2"></span>
                                <span>Perlu Diganti (Lewat Target)</span>
                            </div>
                            <div class="flex items-center">
                                <span class="inline-block w-4 h-4 bg-yellow-100 border-2 border-yellow-500 rounded mr-2"></span>
                                <span>Mendekati Batas (≤20 hari)</span>
                            </div>
                            <div class="flex items-center">
                                <span class="inline-block w-4 h-4 bg-green-100 border-2 border-green-500 rounded mr-2"></span>
                                <span>Terpasang (Normal)</span>
                            </div>
                        </div>
                    </div>
                </div>
            </aside>

            <!-- Main Content Area -->
            <main class="flex-1 p-6">
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-blue-500 text-white">
                                <tr>
                                    <th class="px-4 py-3 text-left">S/N Mesin</th>
                                    <th class="px-4 py-3 text-left">Part Number</th>
                                    <th class="px-4 py-3 text-left">Material</th>
                                    <th class="px-4 py-3 text-left">Tanggal Pasang</th>
                                    <th class="px-4 py-3 text-center">Umur (Hari)</th>
                                    <th class="px-4 py-3 text-center">Target (Hari)</th>
                                    <th class="px-4 py-3 text-center">Sisa (Hari)</th>
                                    <th class="px-4 py-3 text-left">Lokasi</th>
                                    <th class="px-4 py-3 text-center">Status</th>
                                    <th class="px-4 py-3 text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody id="ageTable">
                                <tr>
                                    <td colspan="10" class="px-4 py-8 text-center text-gray-500">
                                        <i class="fas fa-spinner fa-spin text-3xl mb-3"></i>
                                        <p>Memuat data...</p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>

        <script src="/static/auth-check.js"><\/script>
        <script src="/static/dashboard-umur.js"><\/script>
    </body>
    </html>
  `}function Na(){return`
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard Mutasi Material</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <!-- Navigation -->
        <nav class="bg-blue-600 text-white p-4 shadow-lg">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-exchange-alt text-2xl"></i>
                    <span class="text-xl font-bold">Dashboard Mutasi Material</span>
                </div>
                <div class="flex flex-wrap space-x-2">
                    <a href="/" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-plus mr-1"></i>Input Material
                    </a>
                    <a href="/form-gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exclamation-triangle mr-1"></i>Form Gangguan
                    </a>
                    <a href="/dashboard/stok" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-chart-bar mr-1"></i>Stok
                    </a>
                    <a href="/dashboard/umur" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-calendar-alt mr-1"></i>Umur
                    </a>
                    <a href="/dashboard/mutasi" class="px-3 py-2 bg-blue-700 rounded hover:bg-blue-800">
                        <i class="fas fa-exchange-alt mr-1"></i>Mutasi
                    </a>
                    <a href="/dashboard/gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-tools mr-1"></i>Gangguan
                    </a>
                    <a href="/dashboard/kebutuhan-material" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-clipboard-list mr-1"></i>Kebutuhan
                    </a>
                    <button onclick="logout()" class="px-3 py-2 bg-red-600 hover:bg-blue-700 rounded ml-4">
                        <i class="fas fa-sign-out-alt mr-1"></i>Logout
                    </button>
                </div>
            </div>
        </nav>

        <!-- Main Content with Sidebar -->
        <div class="flex">
            <!-- Sidebar Filter (Vertical) -->
            <aside class="w-80 bg-gray-900 shadow-lg min-h-screen p-6">
                <h2 class="text-2xl font-bold text-blue-400 mb-6 flex items-center">
                    <i class="fas fa-filter mr-2"></i>
                    Filter Mutasi
                </h2>
                
                <div class="space-y-6">
                    <!-- Filter Tanggal -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-300 mb-3">
                            <i class="fas fa-calendar mr-2 text-cyan-600"></i>
                            Tanggal
                        </label>
                        <input type="date" id="filterTanggal" 
                            class="w-full px-4 py-2 bg-gray-800 text-white border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500">
                    </div>
                    
                    <!-- Filter Nomor BA -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-300 mb-3">
                            <i class="fas fa-file-alt mr-2 text-cyan-600"></i>
                            Nomor BA
                        </label>
                        <input type="text" id="filterNomorBA" placeholder="Cari Nomor BA..." 
                            class="w-full px-4 py-2 bg-gray-800 text-white border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500">
                    </div>

                    <!-- Export Button -->
                    <div class="mt-8">
                        <button onclick="exportAllBA()" class="w-full bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 font-semibold">
                            <i class="fas fa-file-export mr-2"></i>
                            Export Semua BA
                        </button>
                    </div>

                    <!-- Info Box -->
                    <div class="mt-8 p-4 bg-white rounded-lg shadow-md">
                        <h3 class="font-semibold text-cyan-800 mb-3">
                            <i class="fas fa-info-circle mr-2"></i>
                            Informasi
                        </h3>
                        <div class="space-y-2 text-sm text-gray-700">
                            <p>• Klik Nomor BA untuk melihat detail</p>
                            <p>• Status Terkirim untuk export BA</p>
                            <p>• Filter berdasarkan tanggal dan BA</p>
                        </div>
                    </div>
                </div>
            </aside>

            <!-- Main Content Area -->
            <main class="flex-1 p-6">
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-blue-500 text-white">
                                <tr>
                                    <th class="px-4 py-3 text-left">Nomor BA</th>
                                    <th class="px-4 py-3 text-left">Tanggal</th>
                                    <th class="px-4 py-3 text-left">Jenis Transaksi</th>
                                    <th class="px-4 py-3 text-left">Part Number</th>
                                    <th class="px-4 py-3 text-center">Jumlah</th>
                                    <th class="px-4 py-3 text-left">Lokasi Keluar</th>
                                    <th class="px-4 py-3 text-left">Lokasi Tujuan</th>
                                    <th class="px-4 py-3 text-left">Pemeriksa</th>
                                    <th class="px-4 py-3 text-left">Penerima</th>
                                    <th class="px-4 py-3 text-center">Status BA</th>
                                </tr>
                            </thead>
                            <tbody id="mutasiTable">
                                <tr>
                                    <td colspan="10" class="px-4 py-8 text-center text-gray-500">
                                        <i class="fas fa-spinner fa-spin text-3xl mb-3"></i>
                                        <p>Memuat data...</p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>

        <script src="/static/auth-check.js"><\/script>
        <script src="/static/dashboard-mutasi.js"><\/script>
    </body>
    </html>
  `}function Ra(){return`
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Form Gangguan dan Permintaan Material</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <style>
          .signature-pad {
            border: 2px dashed #cbd5e1;
            border-radius: 8px;
            cursor: crosshair;
          }
          .signature-pad:hover {
            border-color: #3b82f6;
          }
        </style>
    </head>
    <body class="bg-gray-50">
        <!-- Navigation -->
        <nav class="bg-blue-600 text-white p-4 shadow-lg">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-exclamation-triangle text-2xl"></i>
                    <span class="text-xl font-bold">Form Gangguan dan Permintaan Material</span>
                </div>
                <div class="flex flex-wrap space-x-2">
                    <a href="/" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-plus mr-1"></i>Input Material
                    </a>
                    <a href="/form-gangguan" class="px-3 py-2 bg-blue-700 rounded hover:bg-blue-800">
                        <i class="fas fa-exclamation-triangle mr-1"></i>Form Gangguan
                    </a>
                    <a href="/dashboard/stok" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-chart-bar mr-1"></i>Stok
                    </a>
                    <a href="/dashboard/umur" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-calendar-alt mr-1"></i>Umur
                    </a>
                    <a href="/dashboard/mutasi" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exchange-alt mr-1"></i>Mutasi
                    </a>
                    <a href="/dashboard/gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-tools mr-1"></i>Gangguan
                    </a>
                </div>
            </div>
        </nav>

        <div class="min-h-screen py-8 px-4">
            <div class="max-w-6xl mx-auto">
                <!-- Header -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <h1 class="text-3xl font-bold text-gray-800 mb-2">
                        <i class="fas fa-file-alt text-red-600 mr-3"></i>
                        Form Gangguan dan Permintaan Material
                    </h1>
                    <p class="text-gray-600">Berita Acara LH05</p>
                </div>

                <!-- Form -->
                <form id="gangguanForm" class="space-y-6">
                    <!-- BA LH05 Number (Auto) -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            <i class="fas fa-hashtag text-red-600 mr-2"></i>
                            Nomor BA LH05 (Auto)
                        </h2>
                        <div class="bg-gray-100 p-4 rounded-lg">
                            <p class="text-sm text-gray-600 mb-2">Nomor akan di-generate otomatis:</p>
                            <p class="text-2xl font-bold text-red-600">Format: XXX/ND KAL 2/LH05/TAHUN</p>
                            <p class="text-sm text-gray-500 mt-2">Contoh: 001/ND KAL 2/LH05/2025</p>
                        </div>
                    </div>

                    <!-- 1. Hari/Tanggal/Jam Kejadian -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            1. Hari/Tanggal/Jam Kejadian
                        </h2>
                        <input type="datetime-local" id="hariTanggal" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500">
                    </div>

                    <!-- Unit/ULD -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            <i class="fas fa-building text-red-600 mr-2"></i>
                            Unit / ULD
                        </h2>
                        <select id="unitULD" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500">
                            <option value="">-- Pilih Unit/ULD --</option>
                        </select>
                    </div>

                    <!-- 2. Kelompok SPD yang rusak -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            2. Kelompok SPD yang rusak
                        </h2>
                        <select id="kelompokSPD" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500">
                            <option value="">-- Pilih Kelompok SPD --</option>
                            <option value="MEKANIK">MEKANIK</option>
                            <option value="ELEKTRIK">ELEKTRIK</option>
                        </select>
                    </div>

                    <!-- 3-6. Isian Manual -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            Analisa Gangguan
                        </h2>
                        
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    3. Komponen yang rusak
                                </label>
                                <input type="text" id="komponenRusak" required
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    4. Gejala yang timbul
                                </label>
                                <textarea id="gejala" required rows="3"
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    5. Uraian kejadian
                                </label>
                                <textarea id="uraianKejadian" required rows="3"
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    6. Analisa penyebab
                                </label>
                                <textarea id="analisaPenyebab" required rows="3"
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    7. Kesimpulan kerusakan
                                </label>
                                <textarea id="kesimpulan" required rows="3"
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- 8. Akibat terhadap sistem pembangkit -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            8. Akibat terhadap sistem pembangkit
                        </h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    Beban Puncak (MW)
                                </label>
                                <input type="number" id="bebanPuncak" step="0.01" required
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    Daya Mampu (MW)
                                </label>
                                <input type="number" id="dayaMampu" step="0.01" required
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    Status Pemadaman
                                </label>
                                <select id="pemadaman" required
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                                    <option value="">-- Pilih Status --</option>
                                    <option value="NORMAL">NORMAL</option>
                                    <option value="SIAGA">SIAGA</option>
                                    <option value="DEFISIT">DEFISIT</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- 9-10. Tindakan -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            Tindakan dan Rencana
                        </h2>
                        
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    9. Tindakan penanggulangan
                                </label>
                                <textarea id="tindakanPenanggulangan" required rows="3"
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-300 mb-2">
                                    10. Rencana perbaikan
                                </label>
                                <textarea id="rencanaPerbaikan" required rows="3"
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- 11. Kebutuhan Material -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            <i class="fas fa-boxes text-red-600 mr-2"></i>
                            11. Kebutuhan Material
                        </h2>
                        
                        <div id="materialListGangguan" class="space-y-4"></div>
                        
                        <button type="button" id="addMaterialGangguan" 
                            class="w-full mt-4 bg-red-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition flex items-center justify-center">
                            <i class="fas fa-plus mr-2"></i>
                            Tambah Material
                        </button>
                    </div>

                    <!-- 12. TTD Digital -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">
                            <i class="fas fa-signature text-red-600 mr-2"></i>
                            12. Tanda Tangan Digital Pelapor
                        </h2>
                        
                        <div class="max-w-md mx-auto">
                            <label class="block text-sm font-medium text-gray-300 mb-2">Nama Pelapor</label>
                            <input type="text" id="namaPelapor" required placeholder="Nama Pelapor"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg mb-4">
                            
                            <label class="block text-sm font-medium text-gray-300 mb-2">Tanda Tangan Pelapor</label>
                            <canvas id="signaturePelapor" width="400" height="200" class="signature-pad w-full bg-gray-50"></canvas>
                            <button type="button" id="clearPelapor" class="mt-2 text-sm text-red-600 hover:text-red-700">
                                <i class="fas fa-eraser mr-1"></i>Hapus Tanda Tangan
                            </button>
                        </div>
                    </div>

                    <!-- Submit -->
                    <div class="flex gap-4">
                        <button type="submit" 
                            class="flex-1 bg-green-600 text-white py-4 px-6 rounded-lg hover:bg-blue-700 transition text-lg font-semibold">
                            <i class="fas fa-save mr-2"></i>Simpan Form Gangguan
                        </button>
                        <button type="button" id="resetFormGangguan"
                            class="px-6 py-4 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition">
                            <i class="fas fa-undo mr-2"></i>Reset
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <script src="/static/form-gangguan.js"><\/script>
    </body>
    </html>
  `}function Ca(){return`
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login - Sistem Manajemen Material</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gradient-to-br from-blue-500 to-blue-700 min-h-screen flex items-center justify-center">
        <div class="max-w-md w-full mx-4">
            <!-- Login Card -->
            <div class="bg-white rounded-2xl shadow-2xl p-8">
                <!-- Header -->
                <div class="text-center mb-8">
                    <div class="bg-blue-600 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-warehouse text-4xl text-white"></i>
                    </div>
                    <h1 class="text-3xl font-bold text-gray-800 mb-2">Sistem Manajemen Material</h1>
                    <p class="text-gray-600">Silakan login untuk melanjutkan</p>
                </div>

                <!-- Error Message -->
                <div id="errorMessage" class="hidden bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded">
                    <div class="flex items-center">
                        <i class="fas fa-exclamation-circle mr-2"></i>
                        <span id="errorText">Username atau password salah</span>
                    </div>
                </div>

                <!-- Login Form -->
                <form id="loginForm" class="space-y-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-300 mb-2">
                            <i class="fas fa-user mr-2 text-blue-600"></i>Username
                        </label>
                        <input type="text" id="username" required
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                            placeholder="Masukkan username">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-300 mb-2">
                            <i class="fas fa-lock mr-2 text-blue-600"></i>Password
                        </label>
                        <div class="relative">
                            <input type="password" id="password" required
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                placeholder="Masukkan password">
                            <button type="button" id="togglePassword" 
                                class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <button type="submit" id="loginButton"
                        class="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition font-semibold text-lg flex items-center justify-center">
                        <i class="fas fa-sign-in-alt mr-2"></i>
                        <span>Login</span>
                    </button>
                </form>

                <!-- Public Access Link -->
                <div class="mt-8 pt-6 border-t border-gray-200 text-center">
                    <p class="text-gray-600 mb-3">Akses Publik:</p>
                    <a href="/form-gangguan" 
                        class="inline-flex items-center text-blue-600 hover:text-blue-700 font-semibold">
                        <i class="fas fa-exclamation-triangle mr-2"></i>
                        Form Gangguan dan Permintaan Material
                        <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            </div>

            <!-- Footer -->
            <div class="text-center mt-6 text-white">
                <p class="text-sm opacity-80">PT PLN (Persero) Unit Induk Wilayah Kalimantan Selatan & Tengah</p>
            </div>
        </div>

        <script>
          // Toggle password visibility
          document.getElementById('togglePassword').addEventListener('click', function() {
            const passwordInput = document.getElementById('password')
            const icon = this.querySelector('i')
            
            if (passwordInput.type === 'password') {
              passwordInput.type = 'text'
              icon.classList.remove('fa-eye')
              icon.classList.add('fa-eye-slash')
            } else {
              passwordInput.type = 'password'
              icon.classList.remove('fa-eye-slash')
              icon.classList.add('fa-eye')
            }
          })

          // Login form submit
          document.getElementById('loginForm').addEventListener('submit', async function(e) {
            e.preventDefault()
            
            const username = document.getElementById('username').value
            const password = document.getElementById('password').value
            const button = document.getElementById('loginButton')
            const errorDiv = document.getElementById('errorMessage')
            
            // Disable button
            button.disabled = true
            button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Loading...'
            
            try {
              const response = await fetch('/api/login', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
              })
              
              const data = await response.json()
              
              if (data.success) {
                // Save session token
                localStorage.setItem('sessionToken', data.sessionToken)
                
                // Show success and redirect
                button.innerHTML = '<i class="fas fa-check mr-2"></i>Login Berhasil!'
                button.classList.remove('bg-blue-600', 'hover:bg-blue-700')
                button.classList.add('bg-green-600')
                
                setTimeout(() => {
                  window.location.href = '/'
                }, 500)
              } else {
                // Show error
                errorDiv.classList.remove('hidden')
                document.getElementById('errorText').textContent = data.message || 'Login gagal'
                
                // Reset button
                button.disabled = false
                button.innerHTML = '<i class="fas fa-sign-in-alt mr-2"></i>Login'
              }
            } catch (error) {
              console.error('Login error:', error)
              errorDiv.classList.remove('hidden')
              document.getElementById('errorText').textContent = 'Terjadi kesalahan sistem'
              
              // Reset button
              button.disabled = false
              button.innerHTML = '<i class="fas fa-sign-in-alt mr-2"></i>Login'
            }
          })
        <\/script>
    </body>
    </html>
  `}function Ia(){return`
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard Kebutuhan Material</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <nav class="bg-blue-600 text-white p-4 shadow-lg">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-clipboard-list text-2xl"></i>
                    <span class="text-xl font-bold">Dashboard Kebutuhan Material</span>
                </div>
                <div class="flex flex-wrap space-x-2 items-center">
                    <a href="/" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-plus mr-1"></i>Input Material
                    </a>
                    <a href="/form-gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exclamation-triangle mr-1"></i>Form Gangguan
                    </a>
                    <a href="/dashboard/stok" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-chart-bar mr-1"></i>Stok
                    </a>
                    <a href="/dashboard/umur" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-calendar-alt mr-1"></i>Umur
                    </a>
                    <a href="/dashboard/mutasi" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exchange-alt mr-1"></i>Mutasi
                    </a>
                    <a href="/dashboard/gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-tools mr-1"></i>Gangguan
                    </a>
                    <a href="/dashboard/kebutuhan-material" class="px-3 py-2 bg-blue-700 rounded hover:bg-blue-800">
                        <i class="fas fa-clipboard-list mr-1"></i>Kebutuhan
                    </a>
                    <button onclick="logout()" class="px-3 py-2 bg-red-600 hover:bg-blue-700 rounded ml-4">
                        <i class="fas fa-sign-out-alt mr-1"></i>Logout
                    </button>
                </div>
            </div>
        </nav>

        <div class="flex">
            <!-- Sidebar Filter (Kiri) -->
            <div class="w-64 bg-gray-900 shadow-lg p-6 min-h-screen">
                <h2 class="text-xl font-bold mb-6 text-white">
                    <i class="fas fa-filter mr-2 text-blue-400"></i>
                    Filter Data
                </h2>
                
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Filter Status</label>
                        <select id="filterStatus" class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                            <option value="">Semua Status</option>
                            <option value="Pengadaan">Pengadaan</option>
                            <option value="Tunda">Tunda</option>
                            <option value="Reject">Reject</option>
                            <option value="Terkirim">Terkirim</option>
                            <option value="Tersedia">Tersedia</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Filter Mesin</label>
                        <select id="filterMesin" class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                            <option value="">Semua Mesin</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Filter Unit</label>
                        <select id="filterUnit" class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                            <option value="">Semua Unit</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Cari Nomor LH05</label>
                        <input type="text" id="searchNomor" placeholder="Cari nomor..." 
                            class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                    </div>
                    
                    <button onclick="applyFilters()" class="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">
                        <i class="fas fa-search mr-2"></i>Terapkan Filter
                    </button>
                    
                    <button onclick="resetFilters()" class="w-full bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400">
                        <i class="fas fa-undo mr-2"></i>Reset Filter
                    </button>
                </div>
                
                <div class="mt-8 p-4 bg-purple-50 rounded-lg">
                    <h3 class="font-semibold text-purple-800 mb-2">
                        <i class="fas fa-info-circle mr-2"></i>
                        Statistik
                    </h3>
                    <div class="space-y-2 text-sm">
                        <div class="flex justify-between">
                            <span>Total Material:</span>
                            <span id="totalMaterial" class="font-bold">0</span>
                        </div>
                        <div class="flex justify-between">
                            <span>Pengadaan:</span>
                            <span id="totalPengadaan" class="font-bold text-blue-600">0</span>
                        </div>
                        <div class="flex justify-between">
                            <span>Tunda:</span>
                            <span id="totalTunda" class="font-bold text-yellow-600">0</span>
                        </div>
                        <div class="flex justify-between">
                            <span>Reject:</span>
                            <span id="totalReject" class="font-bold text-red-600">0</span>
                        </div>
                        <div class="flex justify-between">
                            <span>Terkirim:</span>
                            <span id="totalTerkirim" class="font-bold text-green-600">0</span>
                        </div>
                        <div class="flex justify-between">
                            <span>Tersedia:</span>
                            <span id="totalTersedia" class="font-bold text-purple-600">0</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Content (Kanan) -->
            <div class="flex-1 p-6">
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <div class="flex justify-between items-center">
                        <h2 class="text-2xl font-bold text-gray-800">
                            <i class="fas fa-boxes mr-2 text-purple-600"></i>
                            Kebutuhan Material
                        </h2>
                        <button onclick="exportExcel()" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                            <i class="fas fa-file-excel mr-2"></i>Export Excel
                        </button>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <table class="w-full">
                        <thead class="bg-blue-500 text-white">
                            <tr>
                                <th class="px-4 py-3 text-center">No</th>
                                <th class="px-4 py-3 text-left">Nomor LH05</th>
                                <th class="px-4 py-3 text-left">Part Number</th>
                                <th class="px-4 py-3 text-left">Material</th>
                                <th class="px-4 py-3 text-left">Mesin</th>
                                <th class="px-4 py-3 text-center">Jumlah</th>
                                <th class="px-4 py-3 text-left">Unit/Lokasi Tujuan</th>
                                <th class="px-4 py-3 text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody id="kebutuhanTable">
                            <tr>
                                <td colspan="8" class="px-4 py-8 text-center text-gray-500">
                                    Belum ada data kebutuhan material
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <script src="/static/auth-check.js"><\/script>
        <script src="/static/dashboard-kebutuhan.js"><\/script>
    </body>
    </html>
  `}function Oa(){return`
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard Gangguan dan Permintaan Material</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <nav class="bg-blue-600 text-white p-4 shadow-lg">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-tools text-2xl"></i>
                    <span class="text-xl font-bold">Dashboard Gangguan dan Permintaan Material</span>
                </div>
                <div class="flex flex-wrap space-x-2">
                    <a href="/" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-plus mr-1"></i>Input Material
                    </a>
                    <a href="/form-gangguan" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exclamation-triangle mr-1"></i>Form Gangguan
                    </a>
                    <a href="/dashboard/stok" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-chart-bar mr-1"></i>Stok
                    </a>
                    <a href="/dashboard/umur" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-calendar-alt mr-1"></i>Umur
                    </a>
                    <a href="/dashboard/mutasi" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-exchange-alt mr-1"></i>Mutasi
                    </a>
                    <a href="/dashboard/gangguan" class="px-3 py-2 bg-blue-700 rounded hover:bg-blue-800">
                        <i class="fas fa-tools mr-1"></i>Gangguan
                    </a>
                    <a href="/dashboard/kebutuhan-material" class="px-3 py-2 hover:bg-blue-700 rounded">
                        <i class="fas fa-clipboard-list mr-1"></i>Kebutuhan
                    </a>
                    <button onclick="logout()" class="px-3 py-2 bg-red-600 hover:bg-blue-700 rounded ml-4">
                        <i class="fas fa-sign-out-alt mr-1"></i>Logout
                    </button>
                </div>
            </div>
        </nav>

        <div class="flex">
            <!-- Sidebar Filter (Kiri) -->
            <div class="w-64 bg-gray-900 shadow-lg p-6 min-h-screen">
                <h2 class="text-xl font-bold mb-6 text-white">
                    <i class="fas fa-filter mr-2 text-blue-400"></i>
                    Filter Data
                </h2>
                
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Kelompok SPD</label>
                        <select id="filterKelompok" class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                            <option value="">Semua</option>
                            <option value="MEKANIK">MEKANIK</option>
                            <option value="ELEKTRIK">ELEKTRIK</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Tanggal</label>
                        <input type="date" id="filterTanggal" class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Status Pemadaman</label>
                        <select id="filterPemadaman" class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                            <option value="">Semua</option>
                            <option value="NORMAL">NORMAL</option>
                            <option value="SIAGA">SIAGA</option>
                            <option value="DEFISIT">DEFISIT</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Filter Unit</label>
                        <select id="filterUnit" class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                            <option value="">Semua Unit</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2 text-gray-300">Cari Nomor LH05</label>
                        <input type="text" id="searchNomor" placeholder="001/ND KAL 2/LH05/2025" 
                            class="w-full px-3 py-2 bg-gray-800 text-white border border-gray-700 rounded-lg text-sm">
                    </div>
                    
                    <button onclick="applyFilters()" class="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">
                        <i class="fas fa-search mr-2"></i>Terapkan Filter
                    </button>
                    
                    <button onclick="resetFilters()" class="w-full bg-gray-700 text-white py-2 rounded-lg hover:bg-gray-600">
                        <i class="fas fa-undo mr-2"></i>Reset Filter
                    </button>
                </div>
                
                <div class="mt-8 p-4 bg-gray-800 rounded-lg">
                    <h3 class="font-semibold text-blue-400 mb-2">
                        <i class="fas fa-info-circle mr-2"></i>
                        Statistik
                    </h3>
                    <div class="space-y-2 text-sm">
                        <div class="flex justify-between">
                            <span class="text-gray-300">Total Gangguan:</span>
                            <span class="text-gray-300" id="totalGangguan" class="font-bold">0</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-300">Mekanik:</span>
                            <span class="text-gray-300" id="totalMekanik" class="font-bold">0</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-300">Elektrik:</span>
                            <span class="text-gray-300" id="totalElektrik" class="font-bold">0</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Content (Kanan) -->
            <div class="flex-1 p-6">
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <div class="flex justify-between items-center">
                        <h2 class="text-2xl font-bold text-gray-800">
                            <i class="fas fa-list-ul mr-2 text-blue-600"></i>
                            Daftar Gangguan dan Permintaan Material
                        </h2>
                        <button onclick="exportAllLH05()" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                            <i class="fas fa-file-export mr-2"></i>Export All
                        </button>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <table class="w-full">
                        <thead class="bg-blue-500 text-white">
                            <tr>
                                <th class="px-4 py-3 text-left">Nomor LH05</th>
                                <th class="px-4 py-3 text-left">Tanggal Kejadian</th>
                                <th class="px-4 py-3 text-left">Kelompok SPD</th>
                                <th class="px-4 py-3 text-left">Komponen Rusak</th>
                                <th class="px-4 py-3 text-center">Beban (MW)</th>
                                <th class="px-4 py-3 text-center">Status</th>
                                <th class="px-4 py-3 text-center">Material</th>
                                <th class="px-4 py-3 text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="gangguanTable">
                            <tr>
                                <td colspan="8" class="px-4 py-8 text-center text-gray-500">
                                    <div class="mb-4">
                                        <i class="fas fa-spinner fa-spin text-4xl text-blue-500 mb-3"></i>
                                        <p class="text-lg font-semibold">Memuat data gangguan...</p>
                                        <p class="text-sm text-gray-400 mt-2">Jika data tidak muncul dalam 5 detik, refresh halaman (F5)</p>
                                    </div>
                                    <div id="debugInfo" class="mt-4 p-4 bg-yellow-50 border-l-4 border-yellow-400 text-left text-sm">
                                        <p class="font-semibold mb-2"><i class="fas fa-info-circle mr-2"></i>Debug Info:</p>
                                        <p>⏳ Loading... mohon tunggu</p>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <script src="/static/auth-check.js"><\/script>
        <script src="/static/dashboard-gangguan.js"><\/script>
        <script>
          // Force load data after auth check completes
          window.addEventListener('load', function() {
            console.log('🔥 FORCE LOADING dashboard gangguan data...')
            setTimeout(function() {
              if (typeof loadDashboardData === 'function') {
                console.log('✅ Calling loadDashboardData() manually')
                loadDashboardData()
              } else {
                console.error('❌ loadDashboardData function not found!')
              }
            }, 1000)
          })
        <\/script>
    </body>
    </html>
  `}const tt=new At,Fa=Object.assign({"/src/index.tsx":b});let St=!1;for(const[,e]of Object.entries(Fa))e&&(tt.all("*",t=>{let a;try{a=t.executionCtx}catch{}return e.fetch(t.req.raw,t.env,a)}),tt.notFound(t=>{let a;try{a=t.executionCtx}catch{}return e.fetch(t.req.raw,t.env,a)}),St=!0);if(!St)throw new Error("Can't import modules from ['/src/index.ts','/src/index.tsx','/app/server.ts']");export{tt as default};
